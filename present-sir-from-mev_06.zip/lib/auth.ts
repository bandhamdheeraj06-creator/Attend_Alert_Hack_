import crypto from 'node:crypto'
import { cookies } from 'next/headers'
import { redirect } from 'next/navigation'
import { getDb } from './db'

export const SESSION_COOKIE = 'attendalert_session'
const SECRET = process.env.SESSION_SECRET || 'attendalert-local-dev-secret'

export type Session = { role: 'mentor' | 'student'; id: string; exp: number }

function sign(value: string) {
  return crypto.createHmac('sha256', SECRET).update(value).digest('base64url')
}

export function encodeSession(session: Omit<Session, 'exp'>) {
  const payload = Buffer.from(
    JSON.stringify({ ...session, exp: Date.now() + 1000 * 60 * 60 * 12 }),
  ).toString('base64url')
  return `${payload}.${sign(payload)}`
}

export async function getSession(): Promise<Session | null> {
  const raw = (await cookies()).get(SESSION_COOKIE)?.value
  if (!raw) return null
  const [payload, signature] = raw.split('.')
  if (!payload || !signature) return null
  const expected = sign(payload)
  if (expected.length !== signature.length || !crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(signature))) {
    return null
  }
  try {
    const session = JSON.parse(Buffer.from(payload, 'base64url').toString()) as Session
    return session.exp > Date.now() ? session : null
  } catch {
    return null
  }
}

export async function requireMentor() {
  const session = await getSession()
  const mentor = session?.role === 'mentor' ? getDb().faculty.find((f) => f.id === session.id) : undefined
  if (!mentor) redirect('/')
  return mentor
}

export async function requireStudent() {
  const session = await getSession()
  const student = session?.role === 'student' ? getDb().students.find((s) => s.id === session.id) : undefined
  if (!student) redirect('/')
  return student
}
