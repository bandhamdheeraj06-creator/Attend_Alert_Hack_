import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { createSeed } from './seed'
import type { DB } from './types'

const DB_FILE = path.join(os.tmpdir(), 'attendalert-db.v1.json')

const store = globalThis as unknown as { __attendAlertDb?: DB }

export function getDb(): DB {
  if (!store.__attendAlertDb) {
    try {
      const parsed = JSON.parse(fs.readFileSync(DB_FILE, 'utf8')) as DB
      store.__attendAlertDb = parsed.version === 1 ? parsed : createSeed()
    } catch {
      store.__attendAlertDb = createSeed()
      saveDb()
    }
  }
  return store.__attendAlertDb
}

export function saveDb() {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(store.__attendAlertDb))
  } catch (error) {
    console.error('[attendalert] Failed to persist JSON store', error)
  }
}

export function resetDb() {
  store.__attendAlertDb = createSeed()
  saveDb()
}

export function uid(prefix: string) {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`
}
