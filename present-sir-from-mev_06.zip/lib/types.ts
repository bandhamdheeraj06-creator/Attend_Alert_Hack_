export type Status = 'P' | 'A' | 'L'

export interface Faculty {
  id: string
  name: string
  email: string
  designation: string
  passwordHash: string
}

export interface Student {
  id: string
  roll: string
  name: string
  email: string
  parentEmail: string
  section: string
  passwordHash: string
}

export interface Subject {
  id: string
  code: string
  name: string
  faculty: string
}

export interface AttendanceSession {
  id: string
  subjectId: string
  date: string
  markedBy: string
}

export interface AttendanceRecord {
  sessionId: string
  studentId: string
  status: Status
}

export type LeaveStatus = 'pending' | 'approved' | 'rejected'

export interface MedicalLeave {
  id: string
  studentId: string
  from: string
  to: string
  reason: string
  fileName: string
  fileDataUrl?: string
  status: LeaveStatus
  submittedAt: string
  reviewedAt?: string
  reviewNote?: string
}

export interface Intervention {
  id: string
  studentId: string
  subjectId: string | null
  note: string
  actionPlan: string
  followUp: string | null
  createdAt: string
  mentorName: string
}

export interface EmailLog {
  id: string
  studentId: string
  to: string[]
  subject: string
  body: string
  createdAt: string
  trigger: 'auto' | 'manual'
}

export interface MidtermMark {
  studentId: string
  subjectId: string
  marks: number
}

export interface DB {
  version: number
  faculty: Faculty[]
  students: Student[]
  subjects: Subject[]
  sessions: AttendanceSession[]
  records: AttendanceRecord[]
  leaves: MedicalLeave[]
  interventions: Intervention[]
  emails: EmailLog[]
  midterms: MidtermMark[]
}
