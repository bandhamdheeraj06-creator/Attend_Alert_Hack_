import { hashPassword } from './password'
import type { AttendanceRecord, AttendanceSession, DB, MedicalLeave, MidtermMark, Status, Student, Subject } from './types'

export const DEMO_MENTOR = { email: 'mentor@attendalert.edu', password: 'mentor123' }
export const DEMO_STUDENT_PASSWORD = 'student123'
export const SEMESTER_START = '2026-10-19'
export const TODAY = '2026-11-16'

const NAMES = [
  'Rahul Verma', 'Priya Patel', 'Sneha Iyer', 'Arjun Nair', 'Kavya Reddy', 'Mohit Sharma',
  'Ananya Gupta', 'Rohan Das', 'Ishita Singh', 'Vikram Rao', 'Neha Joshi', 'Aditya Kulkarni',
  'Pooja Menon', 'Karan Malhotra', 'Divya Pillai', 'Siddharth Jain', 'Meera Krishnan', 'Yash Agarwal',
  'Tanvi Desai', 'Harsh Chauhan', 'Riya Banerjee', 'Nikhil Bhat', 'Shreya Saxena', 'Aman Khanna',
  'Lakshmi Narayan', 'Varun Thakur', 'Aisha Khan', 'Dev Mishra', 'Nandini Ghosh', 'Kunal Mehra',
]

const SUBJECTS: Subject[] = [
  { id: 'sub-ds', code: 'CS301', name: 'Data Structures', faculty: 'Prof. R. Kumar' },
  { id: 'sub-dbms', code: 'CS302', name: 'Database Management Systems', faculty: 'Dr. S. Rao' },
  { id: 'sub-os', code: 'CS303', name: 'Operating Systems', faculty: 'Prof. M. Fernandes' },
  { id: 'sub-cn', code: 'CS304', name: 'Computer Networks', faculty: 'Dr. P. Bose' },
  { id: 'sub-dm', code: 'MA301', name: 'Discrete Mathematics', faculty: 'Prof. L. Natarajan' },
]

// Classes attended out of 16 held per subject [DS, DBMS, OS, CN, DM].
// 12/16 is exactly 75% (one absence away from Warning); 11/16 is Warning; <=10/16 is Critical.
const PROFILES: Record<number, number[]> = {
  0: [10, 13, 12, 14, 13],
  1: [11, 12, 13, 14, 15],
  2: [9, 10, 12, 13, 11],
  3: [13, 12, 8, 12, 14],
  4: [12, 11, 13, 10, 12],
  5: [11, 7, 12, 13, 11],
  6: [12, 12, 12, 12, 12],
  7: [11, 13, 14, 12, 13],
  8: [14, 11, 15, 13, 14],
  9: [12, 14, 11, 13, 12],
  11: [13, 11, 13, 11, 14],
  13: [12, 13, 12, 11, 13],
}

function mulberry32(seed: number) {
  let a = seed
  return () => {
    a |= 0
    a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

function addDays(iso: string, days: number) {
  const d = new Date(`${iso}T00:00:00Z`)
  d.setUTCDate(d.getUTCDate() + days)
  return d.toISOString().slice(0, 10)
}

function shuffle<T>(arr: T[], rand: () => number) {
  const a = [...arr]
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rand() * (i + 1))
    ;[a[i], a[j]] = [a[j], a[i]]
  }
  return a
}

export function createSeed(): DB {
  const studentHash = hashPassword(DEMO_STUDENT_PASSWORD)
  const students: Student[] = NAMES.map((name, i) => {
    const n = String(i + 1).padStart(3, '0')
    const slug = name.toLowerCase().replace(/[^a-z]+/g, '.')
    return {
      id: `stu-${n}`,
      roll: `22CSE${n}`,
      name,
      email: `${slug}@student.attendalert.edu`,
      parentEmail: `parent.${slug}@mail.com`,
      section: 'CSE-A',
      passwordHash: studentHash,
    }
  })

  // 4 weeks, Mon-Fri. Subject j skips weekday j, so each subject meets 4x/week = 16 sessions.
  const sessions: AttendanceSession[] = []
  for (let day = 0; day < 28; day++) {
    const weekday = day % 7
    if (weekday > 4) continue
    const date = addDays(SEMESTER_START, day)
    SUBJECTS.forEach((sub, j) => {
      if (j === weekday) return
      sessions.push({ id: `ses-${sub.code}-${date}`, subjectId: sub.id, date, markedBy: sub.faculty })
    })
  }

  const records: AttendanceRecord[] = []
  const midterms: MidtermMark[] = []
  const absentDates = new Map<string, string[]>()

  students.forEach((student, i) => {
    SUBJECTS.forEach((sub, j) => {
      const subSessions = sessions.filter((s) => s.subjectId === sub.id)
      const total = subSessions.length
      const attended =
        PROFILES[i]?.[j] ?? ((i + j) % 9 === 0 ? 12 : 13 + ((i * 7 + j * 3) % 4))
      const rand = mulberry32(i * 131 + j * 17 + 7)
      const order = shuffle(
        subSessions.map((_, k) => k),
        rand,
      )
      const absentIdx = new Set(order.slice(0, total - attended))
      subSessions.forEach((s, k) => {
        let status: Status = 'P'
        if (absentIdx.has(k)) status = 'A'
        else if (rand() < 0.08) status = 'L'
        if (status === 'A') {
          const key = `${student.id}|${sub.id}`
          absentDates.set(key, [...(absentDates.get(key) ?? []), s.date])
        }
        records.push({ sessionId: s.id, studentId: student.id, status })
      })

      const pct = attended / total
      const noise = (rand() - 0.5) * 9
      midterms.push({
        studentId: student.id,
        subjectId: sub.id,
        marks: Math.max(4, Math.min(30, Math.round(3 + 25 * pct + noise))),
      })
    })
  })

  const kavyaCnAbsences = (absentDates.get('stu-005|sub-cn') ?? []).sort()
  const leaves: MedicalLeave[] = []
  if (kavyaCnAbsences.length) {
    leaves.push({
      id: 'leave-seed-1',
      studentId: 'stu-005',
      from: kavyaCnAbsences[0],
      to: addDays(kavyaCnAbsences[0], 2),
      reason: 'Viral fever - advised bed rest by physician',
      fileName: 'medical-certificate-kavya.pdf',
      status: 'pending',
      submittedAt: '2026-11-12T09:30:00.000Z',
    })
  }

  return {
    version: 1,
    faculty: [
      {
        id: 'fac-001',
        name: 'Dr. Anjali Mehta',
        email: DEMO_MENTOR.email,
        designation: 'Faculty Mentor, CSE-A',
        passwordHash: hashPassword(DEMO_MENTOR.password),
      },
    ],
    students,
    subjects: SUBJECTS,
    sessions,
    records,
    leaves,
    interventions: [
      {
        id: 'int-seed-1',
        studentId: 'stu-003',
        subjectId: 'sub-ds',
        note: 'Student reported long commute and part-time work clashing with morning lectures.',
        actionPlan: 'Shift lab batch to afternoon slot; weekly check-in every Friday.',
        followUp: '2026-11-20',
        createdAt: '2026-11-06T11:00:00.000Z',
        mentorName: 'Dr. Anjali Mehta',
      },
    ],
    emails: [],
    midterms,
  }
}
