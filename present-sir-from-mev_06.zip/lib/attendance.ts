import type { DB, Status, Student, Subject } from './types'

export const THRESHOLD = 75
export const WARNING_FLOOR = 65

export type Tier = 'safe' | 'warning' | 'critical'

export const TIER_RANK: Record<Tier, number> = { critical: 0, warning: 1, safe: 2 }

export function tierFor(pct: number): Tier {
  if (pct >= THRESHOLD) return 'safe'
  if (pct >= WARNING_FLOOR) return 'warning'
  return 'critical'
}

export function percentage(held: number, attended: number) {
  return held === 0 ? 100 : (attended / held) * 100
}

/**
 * ClassesNeeded = ceil((0.75 * held - attended) / 0.25).
 * Multiplying through by 4 gives the exact integer form 3*held - 4*attended,
 * which avoids floating-point drift at the 75% boundary.
 */
export function classesNeeded(held: number, attended: number) {
  return Math.max(0, 3 * held - 4 * attended)
}

/** Consecutive classes that can be missed while staying at or above 75%. */
export function safeSkips(held: number, attended: number) {
  if (held === 0) return 0
  return Math.max(0, Math.floor((4 * attended - 3 * held) / 3))
}

export interface SubjectStat {
  subjectId: string
  held: number
  attended: number
  present: number
  late: number
  absent: number
  exempt: number
  pct: number
  tier: Tier
  needed: number
  canSkip: number
}

export interface StudentSummary {
  student: Pick<Student, 'id' | 'roll' | 'name' | 'email' | 'parentEmail' | 'section'>
  subjects: SubjectStat[]
  overall: { held: number; attended: number; pct: number; tier: Tier }
  tier: Tier
  worst: SubjectStat
}

export function publicStudent(s: Student): StudentSummary['student'] {
  return { id: s.id, roll: s.roll, name: s.name, email: s.email, parentEmail: s.parentEmail, section: s.section }
}

interface Index {
  sessionById: Map<string, { subjectId: string; date: string }>
  recordsByStudent: Map<string, { sessionId: string; status: Status }[]>
  approvedLeavesByStudent: Map<string, { from: string; to: string }[]>
}

export function buildIndex(db: DB): Index {
  const sessionById = new Map(db.sessions.map((s) => [s.id, { subjectId: s.subjectId, date: s.date }]))
  const recordsByStudent = new Map<string, { sessionId: string; status: Status }[]>()
  for (const r of db.records) {
    const list = recordsByStudent.get(r.studentId) ?? []
    list.push({ sessionId: r.sessionId, status: r.status })
    recordsByStudent.set(r.studentId, list)
  }
  const approvedLeavesByStudent = new Map<string, { from: string; to: string }[]>()
  for (const l of db.leaves) {
    if (l.status !== 'approved') continue
    const list = approvedLeavesByStudent.get(l.studentId) ?? []
    list.push({ from: l.from, to: l.to })
    approvedLeavesByStudent.set(l.studentId, list)
  }
  return { sessionById, recordsByStudent, approvedLeavesByStudent }
}

function emptyStat(subjectId: string): SubjectStat {
  return { subjectId, held: 0, attended: 0, present: 0, late: 0, absent: 0, exempt: 0, pct: 100, tier: 'safe', needed: 0, canSkip: 0 }
}

export function finalizeStat(stat: SubjectStat): SubjectStat {
  const pct = percentage(stat.held, stat.attended)
  return {
    ...stat,
    pct,
    tier: tierFor(pct),
    needed: classesNeeded(stat.held, stat.attended),
    canSkip: safeSkips(stat.held, stat.attended),
  }
}

export function summarizeStudent(db: DB, student: Student, idx: Index = buildIndex(db), excludeSessionId?: string): StudentSummary {
  const bySubject = new Map<string, SubjectStat>(db.subjects.map((s) => [s.id, emptyStat(s.id)]))
  const leaves = idx.approvedLeavesByStudent.get(student.id) ?? []

  for (const r of idx.recordsByStudent.get(student.id) ?? []) {
    if (r.sessionId === excludeSessionId) continue
    const session = idx.sessionById.get(r.sessionId)
    if (!session) continue
    const stat = bySubject.get(session.subjectId)
    if (!stat) continue
    if (r.status === 'A' && leaves.some((l) => session.date >= l.from && session.date <= l.to)) {
      stat.exempt++
      continue
    }
    stat.held++
    if (r.status === 'P') {
      stat.present++
      stat.attended++
    } else if (r.status === 'L') {
      stat.late++
      stat.attended++
    } else {
      stat.absent++
    }
  }

  const subjects = [...bySubject.values()].map(finalizeStat)
  const held = subjects.reduce((a, s) => a + s.held, 0)
  const attended = subjects.reduce((a, s) => a + s.attended, 0)
  const overallPct = percentage(held, attended)
  const worst = [...subjects].sort((a, b) => a.pct - b.pct)[0] ?? emptyStat('')
  return {
    student: publicStudent(student),
    subjects,
    overall: { held, attended, pct: overallPct, tier: tierFor(overallPct) },
    tier: worst.tier,
    worst,
  }
}

export function summarizeAll(db: DB) {
  const idx = buildIndex(db)
  return db.students.map((s) => summarizeStudent(db, s, idx))
}

export function subjectName(subjects: Subject[], id: string) {
  return subjects.find((s) => s.id === id)?.name ?? 'Unknown subject'
}

export function formatPct(pct: number) {
  return `${(Math.round(pct * 10) / 10).toFixed(1)}%`
}

export const TIER_LABEL: Record<Tier, string> = {
  safe: 'Safe',
  warning: 'Warning',
  critical: 'Critical',
}
