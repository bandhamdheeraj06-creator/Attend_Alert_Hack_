'use server'

import { cookies } from 'next/headers'
import { redirect } from 'next/navigation'
import { revalidatePath } from 'next/cache'
import { encodeSession, requireMentor, requireStudent, SESSION_COOKIE } from '@/lib/auth'
import { getDb, resetDb, saveDb, uid } from '@/lib/db'
import { verifyPassword, hashPassword } from '@/lib/password'
import { DEMO_STUDENT_PASSWORD } from '@/lib/seed'
import { buildIndex, formatPct, summarizeStudent, type StudentSummary, type SubjectStat } from '@/lib/attendance'
import type { DB, EmailLog, Status } from '@/lib/types'

const ISO_DATE = /^\d{4}-\d{2}-\d{2}$/

function clean(value: FormDataEntryValue | null, max = 2000) {
  return typeof value === 'string' ? value.trim().slice(0, max) : ''
}

/* ---------------- Auth ---------------- */

export type LoginState = { error?: string }

export async function login(_prev: LoginState, formData: FormData): Promise<LoginState> {
  const role = clean(formData.get('role'), 10)
  const identifier = clean(formData.get('identifier'), 120).toLowerCase()
  const password = clean(formData.get('password'), 120)
  if (!identifier || !password) return { error: 'Enter your credentials to continue.' }

  const db = getDb()
  let session: { role: 'mentor' | 'student'; id: string } | null = null
  if (role === 'mentor') {
    const mentor = db.faculty.find((f) => f.email.toLowerCase() === identifier)
    if (mentor && verifyPassword(password, mentor.passwordHash)) session = { role: 'mentor', id: mentor.id }
  } else {
    const student = db.students.find((s) => s.roll.toLowerCase() === identifier || s.email.toLowerCase() === identifier)
    if (student && verifyPassword(password, student.passwordHash)) session = { role: 'student', id: student.id }
  }
  if (!session) return { error: 'Invalid credentials. Check the demo accounts below.' }

  ;(await cookies()).set(SESSION_COOKIE, encodeSession(session), {
    httpOnly: true,
    sameSite: 'none',
    secure: true,
    path: '/',
    maxAge: 60 * 60 * 12,
  })
  redirect(session.role === 'mentor' ? '/mentor' : '/student')
}

export async function logout() {
  ;(await cookies()).delete(SESSION_COOKIE)
  redirect('/')
}

/* ---------------- Email simulation ---------------- */

function buildAlertEmail(db: DB, summary: StudentSummary, trigger: EmailLog['trigger']): EmailLog {
  const atRisk = summary.subjects.filter((s) => s.tier !== 'safe').sort((a, b) => a.pct - b.pct)
  const lines = atRisk.map((s: SubjectStat) => {
    const sub = db.subjects.find((x) => x.id === s.subjectId)
    return `- ${sub?.code} ${sub?.name}: ${formatPct(s.pct)} (${s.attended}/${s.held}) - attend the next ${s.needed} consecutive classes to reach 75%`
  })
  return {
    id: uid('mail'),
    studentId: summary.student.id,
    to: [summary.student.email, summary.student.parentEmail],
    subject: `[AttendAlert] ${summary.tier === 'critical' ? 'CRITICAL' : 'Warning'}: Attendance shortage for ${summary.student.name} (${summary.student.roll})`,
    body: [
      `Dear ${summary.student.name} and Parent/Guardian,`,
      '',
      `This is an automated early-warning notice. University regulations require a minimum of 75% attendance in every subject to be eligible for semester examinations.`,
      '',
      `Current shortage:`,
      ...lines,
      '',
      `Overall attendance: ${formatPct(summary.overall.pct)}`,
      '',
      `Please meet your faculty mentor, Dr. Anjali Mehta, this week to discuss a recovery plan. Approved medical leave can be submitted through the Student Portal for exemption.`,
      '',
      `- AttendAlert, Department of CSE`,
    ].join('\n'),
    createdAt: new Date().toISOString(),
    trigger,
  }
}

/* ---------------- Attendance ---------------- */

export interface SaveAttendanceResult {
  ok: boolean
  error?: string
  sessionDate?: string
  counts?: { present: number; absent: number; late: number }
  newlyCritical?: { id: string; name: string; pct: number; needed: number }[]
}

export async function saveAttendance(input: {
  subjectId: string
  date: string
  marks: Record<string, Status>
}): Promise<SaveAttendanceResult> {
  const mentor = await requireMentor()
  const db = getDb()
  const subject = db.subjects.find((s) => s.id === input.subjectId)
  if (!subject) return { ok: false, error: 'Unknown subject.' }
  if (!ISO_DATE.test(input.date)) return { ok: false, error: 'Invalid date.' }

  const validIds = new Set(db.students.map((s) => s.id))
  const entries = Object.entries(input.marks ?? {}).filter(
    ([id, status]) => validIds.has(id) && (status === 'P' || status === 'A' || status === 'L'),
  )
  if (!entries.length) return { ok: false, error: 'No students marked.' }

  const before = new Map(
    (() => {
      const idx = buildIndex(db)
      return db.students.map((s) => [s.id, summarizeStudent(db, s, idx).subjects.find((x) => x.subjectId === subject.id)!])
    })(),
  )

  let session = db.sessions.find((s) => s.subjectId === subject.id && s.date === input.date)
  if (!session) {
    session = { id: `ses-${subject.code}-${input.date}`, subjectId: subject.id, date: input.date, markedBy: mentor.name }
    db.sessions.push(session)
  }
  const sessionId = session.id
  const touched = new Set(entries.map(([id]) => id))
  db.records = db.records.filter((r) => !(r.sessionId === sessionId && touched.has(r.studentId)))
  for (const [studentId, status] of entries) db.records.push({ sessionId, studentId, status })

  const idx = buildIndex(db)
  const newlyCritical: NonNullable<SaveAttendanceResult['newlyCritical']> = []
  for (const student of db.students) {
    if (!touched.has(student.id)) continue
    const summary = summarizeStudent(db, student, idx)
    const after = summary.subjects.find((x) => x.subjectId === subject.id)!
    if (after.tier === 'critical' && before.get(student.id)?.tier !== 'critical') {
      newlyCritical.push({ id: student.id, name: student.name, pct: after.pct, needed: after.needed })
      db.emails.unshift(buildAlertEmail(db, summary, 'auto'))
    }
  }
  saveDb()
  revalidatePath('/', 'layout')

  const statuses = entries.map(([, s]) => s)
  return {
    ok: true,
    sessionDate: input.date,
    counts: {
      present: statuses.filter((s) => s === 'P').length,
      absent: statuses.filter((s) => s === 'A').length,
      late: statuses.filter((s) => s === 'L').length,
    },
    newlyCritical,
  }
}

/* ---------------- Mentoring ---------------- */

export type InterventionState = { ok?: boolean; error?: string }

export async function logIntervention(_prev: InterventionState, formData: FormData): Promise<InterventionState> {
  const mentor = await requireMentor()
  const db = getDb()
  const studentId = clean(formData.get('studentId'), 40)
  const subjectId = clean(formData.get('subjectId'), 40)
  const note = clean(formData.get('note'))
  const actionPlan = clean(formData.get('actionPlan'))
  const followUp = clean(formData.get('followUp'), 10)
  if (!db.students.some((s) => s.id === studentId)) return { error: 'Student not found.' }
  if (note.length < 5) return { error: 'Add counselling notes (at least 5 characters).' }
  if (followUp && !ISO_DATE.test(followUp)) return { error: 'Invalid follow-up date.' }

  db.interventions.unshift({
    id: uid('int'),
    studentId,
    subjectId: db.subjects.some((s) => s.id === subjectId) ? subjectId : null,
    note,
    actionPlan,
    followUp: followUp || null,
    createdAt: new Date().toISOString(),
    mentorName: mentor.name,
  })
  saveDb()
  revalidatePath('/', 'layout')
  return { ok: true }
}

export async function sendAlertEmail(studentId: string) {
  await requireMentor()
  const db = getDb()
  const student = db.students.find((s) => s.id === studentId)
  if (!student) return { ok: false }
  const summary = summarizeStudent(db, student)
  db.emails.unshift(buildAlertEmail(db, summary, 'manual'))
  saveDb()
  revalidatePath('/', 'layout')
  return { ok: true }
}

export async function sendAllCriticalAlerts() {
  await requireMentor()
  const db = getDb()
  const idx = buildIndex(db)
  let sent = 0
  for (const student of db.students) {
    const summary = summarizeStudent(db, student, idx)
    if (summary.tier !== 'critical') continue
    db.emails.unshift(buildAlertEmail(db, summary, 'manual'))
    sent++
  }
  saveDb()
  revalidatePath('/', 'layout')
  return { sent }
}

/* ---------------- Medical leave ---------------- */

export type LeaveState = { ok?: boolean; error?: string }
const MAX_CERT_BYTES = 1024 * 1024

export async function submitMedicalLeave(_prev: LeaveState, formData: FormData): Promise<LeaveState> {
  const student = await requireStudent()
  const from = clean(formData.get('from'), 10)
  const to = clean(formData.get('to'), 10)
  const reason = clean(formData.get('reason'), 500)
  const file = formData.get('certificate')
  if (!ISO_DATE.test(from) || !ISO_DATE.test(to) || from > to) return { error: 'Choose a valid date range.' }
  if (reason.length < 5) return { error: 'Describe the medical reason.' }
  if (!(file instanceof File) || file.size === 0) return { error: 'Attach a medical certificate (PDF or image).' }
  if (file.size > MAX_CERT_BYTES) return { error: 'Certificate must be under 1 MB.' }
  if (!/^(application\/pdf|image\/(png|jpe?g|webp))$/.test(file.type)) return { error: 'Only PDF, PNG, JPG or WEBP files are accepted.' }

  const buffer = Buffer.from(await file.arrayBuffer())
  const db = getDb()
  db.leaves.unshift({
    id: uid('leave'),
    studentId: student.id,
    from,
    to,
    reason,
    fileName: file.name.slice(0, 120),
    fileDataUrl: `data:${file.type};base64,${buffer.toString('base64')}`,
    status: 'pending',
    submittedAt: new Date().toISOString(),
  })
  saveDb()
  revalidatePath('/', 'layout')
  return { ok: true }
}

export async function reviewMedicalLeave(leaveId: string, decision: 'approved' | 'rejected', note: string) {
  await requireMentor()
  const db = getDb()
  const leave = db.leaves.find((l) => l.id === leaveId)
  if (!leave || (decision !== 'approved' && decision !== 'rejected')) return { ok: false }
  leave.status = decision
  leave.reviewedAt = new Date().toISOString()
  leave.reviewNote = note.slice(0, 300)
  saveDb()
  revalidatePath('/', 'layout')
  return { ok: true }
}

/* ---------------- CSV import ---------------- */

export interface ImportResult {
  ok: boolean
  error?: string
  created?: number
  updated?: number
  skipped?: number
  sessionsCreated?: number
}

export async function importRoster(rows: { roll: string; name: string; email: string; parentEmail: string; section: string }[]): Promise<ImportResult> {
  await requireMentor()
  if (!Array.isArray(rows) || rows.length === 0) return { ok: false, error: 'No rows to import.' }
  if (rows.length > 2000) return { ok: false, error: 'Limit 2000 rows per import.' }
  const db = getDb()
  let created = 0
  let updated = 0
  let skipped = 0
  const defaultHash = hashPassword(DEMO_STUDENT_PASSWORD)
  for (const raw of rows) {
    const roll = String(raw.roll ?? '').trim().toUpperCase().slice(0, 20)
    const name = String(raw.name ?? '').trim().slice(0, 80)
    if (!roll || !name) {
      skipped++
      continue
    }
    const email = String(raw.email ?? '').trim().slice(0, 120) || `${roll.toLowerCase()}@student.attendalert.edu`
    const parentEmail = String(raw.parentEmail ?? '').trim().slice(0, 120)
    const section = String(raw.section ?? '').trim().slice(0, 20) || 'CSE-A'
    const existing = db.students.find((s) => s.roll === roll)
    if (existing) {
      Object.assign(existing, { name, email, parentEmail: parentEmail || existing.parentEmail, section })
      updated++
    } else {
      db.students.push({ id: uid('stu'), roll, name, email, parentEmail, section, passwordHash: defaultHash })
      created++
    }
  }
  saveDb()
  revalidatePath('/', 'layout')
  return { ok: true, created, updated, skipped }
}

const STATUS_MAP: Record<string, Status> = { p: 'P', present: 'P', a: 'A', absent: 'A', l: 'L', late: 'L', '1': 'P', '0': 'A' }

export async function importAttendance(rows: { date: string; subjectCode: string; roll: string; status: string }[]): Promise<ImportResult> {
  const mentor = await requireMentor()
  if (!Array.isArray(rows) || rows.length === 0) return { ok: false, error: 'No rows to import.' }
  if (rows.length > 20000) return { ok: false, error: 'Limit 20000 rows per import.' }
  const db = getDb()
  let created = 0
  let updated = 0
  let skipped = 0
  let sessionsCreated = 0
  for (const raw of rows) {
    const date = String(raw.date ?? '').trim()
    const subject = db.subjects.find((s) => s.code.toUpperCase() === String(raw.subjectCode ?? '').trim().toUpperCase())
    const student = db.students.find((s) => s.roll === String(raw.roll ?? '').trim().toUpperCase())
    const status = STATUS_MAP[String(raw.status ?? '').trim().toLowerCase()]
    if (!ISO_DATE.test(date) || !subject || !student || !status) {
      skipped++
      continue
    }
    let session = db.sessions.find((s) => s.subjectId === subject.id && s.date === date)
    if (!session) {
      session = { id: `ses-${subject.code}-${date}`, subjectId: subject.id, date, markedBy: `${mentor.name} (CSV)` }
      db.sessions.push(session)
      sessionsCreated++
    }
    const existing = db.records.find((r) => r.sessionId === session!.id && r.studentId === student.id)
    if (existing) {
      existing.status = status
      updated++
    } else {
      db.records.push({ sessionId: session.id, studentId: student.id, status })
      created++
    }
  }
  saveDb()
  revalidatePath('/', 'layout')
  return { ok: true, created, updated, skipped, sessionsCreated }
}

export async function resetDemoData() {
  await requireMentor()
  resetDb()
  revalidatePath('/', 'layout')
  return { ok: true }
}
