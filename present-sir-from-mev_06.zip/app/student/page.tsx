import { AlertOctagon, CheckCircle2, LogOut, Lock, TriangleAlert } from 'lucide-react'
import { requireStudent } from '@/lib/auth'
import { getDb } from '@/lib/db'
import { formatPct, summarizeStudent } from '@/lib/attendance'
import { logout } from '@/app/actions'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Brand } from '@/components/brand'
import { AttendanceBar, RiskBadge, tierTextClass } from '@/components/risk-badge'
import { AttendanceStrip } from '@/components/attendance-strip'
import { MedicalLeaveForm } from '@/components/medical-leave-form'
import { cn } from '@/lib/utils'

export const metadata = { title: 'My Attendance' }

export default async function StudentPortal() {
  const student = await requireStudent()
  const db = getDb()
  const summary = summarizeStudent(db, student)
  const sessionMap = new Map(db.sessions.map((s) => [s.id, s]))
  const myLeaves = db.leaves.filter((l) => l.studentId === student.id)
  const shortages = summary.subjects.filter((s) => s.tier !== 'safe')

  return (
    <div className="min-h-dvh bg-background">
      <header className="border-b bg-card">
        <div className="mx-auto flex max-w-5xl items-center justify-between gap-4 px-4 py-3">
          <Brand />
          <div className="flex items-center gap-3">
            <span className="hidden items-center gap-1.5 text-xs text-muted-foreground sm:inline-flex">
              <Lock className="size-3" aria-hidden="true" /> Private view
            </span>
            <form action={logout}>
              <Button variant="ghost" size="sm" type="submit">
                <LogOut className="size-4" aria-hidden="true" /> Sign out
              </Button>
            </form>
          </div>
        </div>
      </header>

      <main className="mx-auto flex max-w-5xl flex-col gap-6 px-4 py-6">
        <div>
          <p className="text-sm text-muted-foreground">Welcome back</p>
          <h1 className="text-2xl font-semibold tracking-tight">{student.name}</h1>
          <p className="font-mono text-sm text-muted-foreground">{student.roll} {'·'} {student.section}</p>
        </div>

        <Card
          className={cn(
            'flex-col gap-4 p-5 sm:flex-row sm:items-center',
            summary.tier === 'critical' && 'border-critical/30 bg-critical-soft',
            summary.tier === 'warning' && 'border-warning/30 bg-warning-soft',
            summary.tier === 'safe' && 'border-safe/30 bg-safe-soft',
          )}
        >
          <span className={cn('flex size-12 shrink-0 items-center justify-center rounded-full text-white', summary.tier === 'critical' ? 'bg-critical' : summary.tier === 'warning' ? 'bg-warning' : 'bg-safe')}>
            {summary.tier === 'critical' ? <AlertOctagon className="size-6" aria-hidden="true" /> : summary.tier === 'warning' ? <TriangleAlert className="size-6" aria-hidden="true" /> : <CheckCircle2 className="size-6" aria-hidden="true" />}
          </span>
          <div className="flex-1">
            {shortages.length === 0 ? (
              <>
                <p className="text-lg font-semibold text-safe">You are eligible in every subject</p>
                <p className="text-sm text-muted-foreground">Keep it up - overall attendance {formatPct(summary.overall.pct)}.</p>
              </>
            ) : (
              <>
                <p className={cn('text-lg font-semibold', tierTextClass(summary.tier))}>
                  Attendance shortage in {shortages.length} subject{shortages.length > 1 ? 's' : ''}
                </p>
                <p className="text-pretty text-sm">
                  Attend the next <strong>{summary.worst.needed}</strong> {db.subjects.find((s) => s.id === summary.worst.subjectId)?.name} classes without
                  missing any to regain exam eligibility (75%).
                </p>
              </>
            )}
          </div>
          <div className="text-right">
            <p className="text-xs text-muted-foreground">Overall</p>
            <p className={cn('font-mono text-3xl font-semibold tabular-nums', tierTextClass(summary.overall.tier))}>{formatPct(summary.overall.pct)}</p>
          </div>
        </Card>

        <section aria-label="Subjects" className="grid gap-4 md:grid-cols-2">
          {summary.subjects.map((s) => {
            const sub = db.subjects.find((x) => x.id === s.subjectId)!
            const hist = db.records
              .filter((r) => r.studentId === student.id && sessionMap.get(r.sessionId)?.subjectId === s.subjectId)
              .map((r) => ({ date: sessionMap.get(r.sessionId)!.date, status: r.status }))
              .sort((a, b) => a.date.localeCompare(b.date))
            return (
              <Card key={s.subjectId} className="gap-3 p-4">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="font-mono text-xs text-muted-foreground">{sub.code}</p>
                    <h2 className="font-semibold">{sub.name}</h2>
                    <p className="text-xs text-muted-foreground">{sub.faculty}</p>
                  </div>
                  <RiskBadge tier={s.tier} />
                </div>
                <div className="flex items-end justify-between">
                  <span className={cn('font-mono text-2xl font-semibold tabular-nums', tierTextClass(s.tier))}>{formatPct(s.pct)}</span>
                  <span className="text-xs tabular-nums text-muted-foreground">{s.attended} / {s.held} attended</span>
                </div>
                <AttendanceBar pct={s.pct} tier={s.tier} />
                <p className="text-sm">
                  {s.needed > 0 ? (
                    <span className={tierTextClass(s.tier)}>Attend next <strong>{s.needed}</strong> classes in a row to reach 75%</span>
                  ) : s.canSkip > 0 ? (
                    <span className="text-muted-foreground">You can miss up to {s.canSkip} class{s.canSkip > 1 ? 'es' : ''} and stay above 75%</span>
                  ) : (
                    <span className="text-warning">Right at the limit - do not miss the next class</span>
                  )}
                </p>
                <AttendanceStrip items={hist} />
              </Card>
            )
          })}
        </section>

        <div className="grid gap-6 md:grid-cols-2">
          <Card className="gap-4 p-5">
            <div>
              <h2 className="font-semibold">Request medical exemption</h2>
              <p className="text-pretty text-sm text-muted-foreground">Absences in an approved range are excluded from your attendance calculation.</p>
            </div>
            <MedicalLeaveForm />
          </Card>
          <Card className="gap-0 p-0">
            <h2 className="border-b p-4 font-semibold">My requests</h2>
            {myLeaves.length === 0 ? (
              <p className="p-4 text-sm text-muted-foreground">No medical leave requests.</p>
            ) : (
              <ul className="divide-y text-sm">
                {myLeaves.map((l) => (
                  <li key={l.id} className="flex items-center justify-between gap-2 p-4">
                    <div>
                      <p className="font-medium">{l.from} to {l.to}</p>
                      <p className="text-xs text-muted-foreground">{l.reason}</p>
                    </div>
                    <span
                      className={cn(
                        'rounded-full px-2 py-0.5 text-xs font-semibold capitalize',
                        l.status === 'approved' ? 'bg-safe-soft text-safe' : l.status === 'rejected' ? 'bg-critical-soft text-critical' : 'bg-warning-soft text-warning',
                      )}
                    >
                      {l.status}
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </Card>
        </div>
      </main>
    </div>
  )
}
