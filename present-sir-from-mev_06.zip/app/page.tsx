import { redirect } from 'next/navigation'
import { BellRing, Calculator, ClipboardCheck, ShieldAlert } from 'lucide-react'
import { getSession } from '@/lib/auth'
import { Brand } from '@/components/brand'
import { LoginForm } from '@/components/login-form'

const FEATURES = [
  { icon: ClipboardCheck, title: 'One-click marking', text: 'Everyone starts Present. Tap only the absentees.' },
  { icon: ShieldAlert, title: 'Risk tiers', text: 'Safe, Warning and Critical, recalculated on every save.' },
  { icon: Calculator, title: 'Recovery estimator', text: 'Exact consecutive classes needed to get back to 75%.' },
  { icon: BellRing, title: 'Auto alerts', text: 'Students and parents get an email when they hit Critical.' },
]

export default async function HomePage() {
  const session = await getSession()
  if (session) redirect(session.role === 'mentor' ? '/mentor' : '/student')

  return (
    <main className="grid min-h-dvh lg:grid-cols-[1.1fr_1fr]">
      <section className="relative hidden flex-col justify-between overflow-hidden bg-sidebar p-10 text-sidebar-foreground lg:flex">
        <Brand inverted />
        <div className="flex max-w-lg flex-col gap-6">
          <p className="text-sm font-medium uppercase tracking-widest text-sidebar-primary">Early-warning analytics</p>
          <h1 className="text-pretty text-4xl font-semibold leading-tight tracking-tight text-white">
            Catch attendance shortages weeks before hall tickets are withheld.
          </h1>
          <p className="text-pretty leading-relaxed text-sidebar-foreground/70">
            AttendAlert continuously computes every student&apos;s attendance against the 75% rule, forecasts detention
            risk, and tells mentors exactly who needs help and how many classes it will take.
          </p>
          <ul className="grid grid-cols-2 gap-4">
            {FEATURES.map(({ icon: Icon, title, text }) => (
              <li key={title} className="rounded-xl border border-sidebar-border bg-sidebar-accent/50 p-4">
                <Icon className="mb-3 size-5 text-sidebar-primary" aria-hidden="true" />
                <p className="text-sm font-semibold text-white">{title}</p>
                <p className="mt-1 text-xs leading-relaxed text-sidebar-foreground/70">{text}</p>
              </li>
            ))}
          </ul>
        </div>
        <div className="flex items-center gap-6 font-mono text-xs text-sidebar-foreground/60">
          <span>ClassesNeeded = ceil((0.75 x Total - Attended) / 0.25)</span>
        </div>
      </section>

      <section className="flex items-center justify-center p-6 sm:p-10">
        <div className="w-full max-w-sm">
          <Brand className="mb-10 lg:hidden" />
          <h2 className="text-2xl font-semibold tracking-tight">Welcome back</h2>
          <p className="mb-8 mt-1 text-sm text-muted-foreground">Sign in to your AttendAlert workspace.</p>
          <LoginForm />
        </div>
      </section>
    </main>
  )
}
