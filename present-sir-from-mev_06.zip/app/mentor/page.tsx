import Link from 'next/link'
import { AlertOctagon, ArrowRight, ClipboardCheck, ShieldCheck, TriangleAlert, Users } from 'lucide-react'
import { getDb } from '@/lib/db'
import { formatPct, summarizeAll, tierFor } from '@/lib/attendance'
import { buttonVariants } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { PageHeader } from '@/components/page-header'
import { AtRiskTable, type RiskRow } from '@/components/at-risk-table'
import { AttendanceBar, tierTextClass } from '@/components/risk-badge'
import { ResetDemoButton } from '@/components/reset-demo-button'
import { cn } from '@/lib/utils'

export const metadata = { title: 'Mentor Dashboard' }

export default function MentorDashboard() {
  const db = getDb()
  const summaries = summarizeAll(db)
  const critical = summaries.filter((s) => s.tier === 'critical').sort((a, b) => a.worst.pct - b.worst.pct)
  const warning = summaries.filter((s) => s.tier === 'warning')
  const safe = summaries.filter((s) => s.tier === 'safe')
  const classAvg = summaries.reduce((a, s) => a + s.overall.pct, 0) / Math.max(1, summaries.length)

  const rows: RiskRow[] = summaries.map((s) => ({
    id: s.student.id,
    roll: s.student.roll,
    name: s.student.name,
    overallPct: s.overall.pct,
    subjects: s.subjects.map((x) => ({
      subjectId: x.subjectId,
      pct: x.pct,
      tier: x.tier,
      needed: x.needed,
      attended: x.attended,
      held: x.held,
    })),
  }))

  const subjectOverview = db.subjects.map((sub) => {
    const stats = summaries.map((s) => s.subjects.find((x) => x.subjectId === sub.id)!)
    const avg = stats.reduce((a, s) => a + s.pct, 0) / Math.max(1, stats.length)
    return {
      ...sub,
      avg,
      critical: stats.filter((s) => s.tier === 'critical').length,
      warning: stats.filter((s) => s.tier === 'warning').length,
      held: Math.max(0, ...stats.map((s) => s.held)),
    }
  })

  const cards = [
    { label: 'Students', value: summaries.length, hint: `${db.students[0]?.section ?? ''} mentee group`, icon: Users, tone: 'text-primary bg-accent' },
    { label: 'Safe (>= 75%)', value: safe.length, hint: 'Eligible in every subject', icon: ShieldCheck, tone: 'text-safe bg-safe-soft' },
    { label: 'Warning (65-74%)', value: warning.length, hint: 'Counsel before it slips', icon: TriangleAlert, tone: 'text-warning bg-warning-soft' },
    { label: 'Critical (< 65%)', value: critical.length, hint: 'Detention risk', icon: AlertOctagon, tone: 'text-critical bg-critical-soft' },
  ]

  return (
    <>
      <PageHeader
        title="Mentor Dashboard"
        description="Live attendance against the 75% eligibility rule. Tiers are based on each student's lowest subject."
        actions={
          <>
            <ResetDemoButton />
            <Link href="/mentor/attendance" className={buttonVariants({ size: 'lg' })}>
              <ClipboardCheck className="size-4" aria-hidden="true" />
              Mark attendance
            </Link>
          </>
        }
      />

      {critical.length > 0 && (
        <section
          aria-label="Critical shortage alert"
          className="flex flex-col gap-4 rounded-xl border border-critical/30 bg-critical-soft p-4 sm:flex-row sm:items-center sm:p-5"
        >
          <span className="flex size-11 shrink-0 items-center justify-center rounded-full bg-critical text-white">
            <AlertOctagon className="size-6" aria-hidden="true" />
          </span>
          <div className="flex-1">
            <p className="text-lg font-semibold text-critical">
              {critical.length} {critical.length === 1 ? 'Student' : 'Students'} in Critical Shortage ({'<'}65%)
            </p>
            <div className="mt-2 flex flex-wrap gap-2">
              {critical.map((s) => (
                <Link
                  key={s.student.id}
                  href={`/mentor/students/${s.student.id}`}
                  className="rounded-full bg-card px-2.5 py-1 text-xs font-medium ring-1 ring-critical/20 hover:ring-critical"
                >
                  {s.student.name}{' '}
                  <span className="font-mono text-critical">{formatPct(s.worst.pct)}</span>{' '}
                  <span className="text-muted-foreground">
                    {db.subjects.find((x) => x.id === s.worst.subjectId)?.code}
                  </span>
                </Link>
              ))}
            </div>
          </div>
          <Link href="/mentor/alerts" className={cn(buttonVariants({ variant: 'destructive', size: 'lg' }), 'bg-critical text-white hover:bg-critical/90')}>
            Open Notification Hub
            <ArrowRight className="size-4" aria-hidden="true" />
          </Link>
        </section>
      )}

      <section aria-label="Summary" className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {cards.map(({ label, value, hint, icon: Icon, tone }) => (
          <Card key={label} className="flex-row items-center gap-4 p-4">
            <span className={cn('flex size-10 shrink-0 items-center justify-center rounded-lg', tone)}>
              <Icon className="size-5" aria-hidden="true" />
            </span>
            <div className="min-w-0">
              <p className="text-2xl font-semibold tabular-nums">{value}</p>
              <p className="truncate text-xs font-medium">{label}</p>
              <p className="hidden truncate text-xs text-muted-foreground sm:block">{hint}</p>
            </div>
          </Card>
        ))}
      </section>

      <div className="grid gap-6 xl:grid-cols-[1fr_320px]">
        <AtRiskTable rows={rows} subjects={db.subjects.map(({ id, code, name }) => ({ id, code, name }))} />

        <Card className="h-fit gap-0 p-0">
          <div className="border-b p-4">
            <h2 className="font-semibold">Subject health</h2>
            <p className="text-xs text-muted-foreground">
              Class average {formatPct(classAvg)} across {subjectOverview[0]?.held ?? 0} sessions per subject
            </p>
          </div>
          <ul className="divide-y">
            {subjectOverview.map((s) => {
              const tier = tierFor(s.avg)
              return (
                <li key={s.id} className="flex flex-col gap-2 p-4">
                  <div className="flex items-baseline justify-between gap-2">
                    <p className="text-sm font-medium">
                      <span className="mr-1.5 font-mono text-xs text-muted-foreground">{s.code}</span>
                      {s.name}
                    </p>
                    <span className={cn('font-mono text-sm font-semibold tabular-nums', tierTextClass(tier))}>
                      {formatPct(s.avg)}
                    </span>
                  </div>
                  <AttendanceBar pct={s.avg} tier={tier} />
                  <p className="text-xs text-muted-foreground">
                    <span className="font-medium text-critical">{s.critical} critical</span>
                    {' · '}
                    <span className="font-medium text-warning">{s.warning} warning</span>
                    {' · '}
                    {s.faculty}
                  </p>
                </li>
              )
            })}
          </ul>
        </Card>
      </div>
    </>
  )
}
