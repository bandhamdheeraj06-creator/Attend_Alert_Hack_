import { getDb } from '@/lib/db'
import { buildIndex } from '@/lib/attendance'
import { PageHeader } from '@/components/page-header'
import { AttendanceSheet, type SheetStudent } from '@/components/attendance-sheet'
import type { Status } from '@/lib/types'

export const metadata = { title: 'Mark Attendance' }

export default function AttendancePage() {
  const db = getDb()
  const idx = buildIndex(db)
  const today = new Date().toISOString().slice(0, 10)

  const existing: Record<string, Record<string, Status>> = {}
  const sessionKey = new Map(db.sessions.map((s) => [s.id, `${s.subjectId}|${s.date}`]))
  for (const r of db.records) {
    const key = sessionKey.get(r.sessionId)
    if (!key) continue
    ;(existing[key] ??= {})[r.studentId] = r.status
  }

  // Base totals per student/subject excluding today's session so the sheet can project "after save" live.
  const todaySessions = new Set(db.sessions.filter((s) => s.date === today).map((s) => s.id))
  const students: SheetStudent[] = db.students.map((student) => {
    const base: SheetStudent['base'] = Object.fromEntries(db.subjects.map((s) => [s.id, { held: 0, attended: 0 }]))
    const leaves = idx.approvedLeavesByStudent.get(student.id) ?? []
    for (const r of idx.recordsByStudent.get(student.id) ?? []) {
      if (todaySessions.has(r.sessionId)) continue
      const session = idx.sessionById.get(r.sessionId)
      if (!session) continue
      if (r.status === 'A' && leaves.some((l) => session.date >= l.from && session.date <= l.to)) continue
      const b = base[session.subjectId]
      b.held++
      if (r.status !== 'A') b.attended++
    }
    return { id: student.id, roll: student.roll, name: student.name, base }
  })

  return (
    <>
      <PageHeader
        title="Mark Attendance"
        description="Present / Late / Absent for each student. Late counts as attended. Percentages update live before you save."
      />
      <AttendanceSheet
        students={students}
        subjects={db.subjects.map(({ id, code, name, faculty }) => ({ id, code, name, faculty }))}
        existing={existing}
        defaultDate={today}
      />
    </>
  )
}
