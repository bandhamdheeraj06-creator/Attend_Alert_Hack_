import { requireMentor } from '@/lib/auth'
import { getDb } from '@/lib/db'
import { summarizeAll } from '@/lib/attendance'
import { MentorNav } from '@/components/mentor-nav'

export default async function MentorLayout({ children }: { children: React.ReactNode }) {
  const mentor = await requireMentor()
  const db = getDb()
  const critical = summarizeAll(db).filter((s) => s.tier === 'critical').length
  const leaves = db.leaves.filter((l) => l.status === 'pending').length

  return (
    <div className="flex min-h-dvh flex-col lg:flex-row">
      <MentorNav mentor={{ name: mentor.name, designation: mentor.designation }} counts={{ critical, leaves }} />
      <main className="min-w-0 flex-1">
        <div className="mx-auto flex max-w-7xl flex-col gap-6 p-4 sm:p-6 lg:p-8">{children}</div>
      </main>
    </div>
  )
}
