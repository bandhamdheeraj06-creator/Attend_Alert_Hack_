import Link from 'next/link'
import { notFound } from 'next/navigation'
import { ArrowLeft, CalendarClock, Mail, NotebookPen, Phone } from 'lucide-react'
import { getDb } from '@/lib/db'
import { formatPct, summarizeStudent } from '@/lib/attendance'
import { buttonVariants } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { AttendanceBar, RiskBadge, tierTextClass } from '@/components/risk-badge'
import { RecoverySimulator } from '@/components/recovery-simulator'
import { InterventionForm } from '@/components/intervention-form'
import { SendAlertButton } from '@/components/send-alert-button'
import { AttendanceStrip } from '@/components/attendance-strip'
import { cn } from '@/lib/utils'

export async function generateMetadata({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const student = getDb().students.find((s) => s.id === id)
  return { title: student ? student.name : 'Student' }
}

export default async function StudentDetail({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const db = getDb()
  const student = db.students.find((s) => s.id === id)
  if (!student) notFound()

  const summary = summarizeStudent(db, student)
  const worstSub = db.subjects.find((s) => s.id === summary.worst.subjectId)
  const interventions = db.interventions.filter((i) => i.studentId === id)
  const emails = db.emails.filter((e) => e.studentId === id).slice(0, 3)
  const leaves = db.leaves.filter((l) => l.studentId === id)

  const sessionMap = new Map(db.sessions.map((s) => [s.id, s]))
  const history = db.subjects.map((sub) => ({
    subjectId: sub.id,
    items: db.records
      .filter((r) => r.studentId === id && sessionMap.get(r.sessionId)?.subjectId === sub.id)
      .map((r) => ({ date: sessionMap.get(r.sessionId)!.date, status: r.status }))
      .sort((a, b) => a.date.localeCompare(b.date)),
  }))

  return (
    <>
      <Link href="/mentor" className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="size-4" aria-hidden="true" /> Back to dashboard
      </Link>

      <Card className="gap-5 p-5 sm:p-6">
        <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
          <div className="flex items-center gap-4">
            <span className="flex size-14 shrink-0 items-center justify-center rounded-full bg-accent text-lg font-semibold text-accent-foreground">
              {student.name.split(' ').map((n) => n[0]).join('')}
            </span>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h1 className="text-2xl font-semibold tracking-tight">{student.name}</h1>
                <RiskBadge tier={summary.tier} />
              </div>
              <p className="font-mono text-sm text-muted-foreground">
                {student.roll} {'·'} {student.section}
              </p>
              <p className="mt-1 flex flex-wrap gap-x-4 text-xs text-muted-foreground">
                <span className="inline-flex items-center gap-1"><Mail className="size-3" aria-hidden="true" />{student.email}</span>
                <span className="inline-flex items-center gap-1"><Phone className="size-3" aria-hidden="true" />Parent: {student.parentEmail}</span>
              </p>
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            <SendAlertButton studentId={student.id} />
            <a href="#log-intervention" className={buttonVariants()}>
              <NotebookPen className="size-4" aria-hidden="true" />
              Log Mentoring Intervention
            </a>
          </div>
        </div>

        {summary.worst.needed > 0 && worstSub && (
          <div
            className={cn(
              'rounded-xl border p-4 sm:p-5',
              summary.tier === 'critical' ? 'border-critical/30 bg-critical-soft' : 'border-warning/30 bg-warning-soft',
            )}
          >
            <p className="text-sm text-muted-foreground">Condonation / recovery estimate</p>
            <p className="mt-1 text-pretty text-lg leading-snug">
              {student.name.split(' ')[0]} is at{' '}
              <span className={cn('font-mono font-semibold', tierTextClass(summary.worst.tier))}>{formatPct(summary.worst.pct)}</span> in{' '}
              <strong>{worstSub.name}</strong> and must attend the next{' '}
              <span className={cn('font-mono text-2xl font-bold', tierTextClass(summary.worst.tier))}>{summary.worst.needed}</span>{' '}
              consecutive classes without absence to reach 75%.
            </p>
            <div className="mt-3 flex flex-wrap gap-1" aria-hidden="true">
              {Array.from({ length: Math.min(summary.worst.needed, 40) }).map((_, i) => (
                <span key={i} className="flex size-6 items-center justify-center rounded bg-card text-[10px] font-mono font-semibold ring-1 ring-border">
                  {i + 1}
                </span>
              ))}
            </div>
            <p className="mt-3 font-mono text-xs text-muted-foreground">
              ceil((0.75 x {summary.worst.held} - {summary.worst.attended}) / 0.25) = {summary.worst.needed}
            </p>
          </div>
        )}
      </Card>

      <div className="grid gap-6 xl:grid-cols-[1fr_380px]">
        <div className="flex flex-col gap-6">
          <Card className="gap-0 p-0">
            <div className="flex items-center justify-between border-b p-4">
              <h2 className="font-semibold">Subject-wise attendance</h2>
              <span className="text-xs text-muted-foreground">
                Overall <span className={cn('font-mono font-semibold', tierTextClass(summary.overall.tier))}>{formatPct(summary.overall.pct)}</span>
              </span>
            </div>
            <ul className="divide-y">
              {summary.subjects.map((s) => {
                const sub = db.subjects.find((x) => x.id === s.subjectId)!
                const hist = history.find((h) => h.subjectId === s.subjectId)!.items
                return (
                  <li key={s.subjectId} className="flex flex-col gap-3 p-4">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <p className="font-medium">
                        <span className="mr-1.5 font-mono text-xs text-muted-foreground">{sub.code}</span>
                        {sub.name}
                      </p>
                      <div className="flex items-center gap-2">
                        <span className={cn('font-mono text-sm font-semibold tabular-nums', tierTextClass(s.tier))}>{formatPct(s.pct)}</span>
                        <RiskBadge tier={s.tier} />
                      </div>
                    </div>
                    <AttendanceBar pct={s.pct} tier={s.tier} />
                    <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-muted-foreground">
                      <span className="tabular-nums">
                        {s.present} present {'·'} {s.late} late {'·'} {s.absent} absent{s.exempt > 0 && ` · ${s.exempt} exempt (medical)`} {'·'} {s.held} held
                      </span>
                      <span className="font-medium text-foreground">
                        {s.needed > 0 ? `Needs ${s.needed} consecutive classes` : s.canSkip > 0 ? `Can miss ${s.canSkip} and stay safe` : 'On the edge - no absences allowed'}
                      </span>
                    </div>
                    <AttendanceStrip items={hist} />
                  </li>
                )
              })}
            </ul>
          </Card>

          <Card className="p-5">
            <InterventionForm
              studentId={student.id}
              subjects={db.subjects.map(({ id, code, name }) => ({ id, code, name }))}
              defaultSubjectId={summary.worst.tier !== 'safe' ? summary.worst.subjectId : ''}
            />
          </Card>
        </div>

        <div className="flex flex-col gap-6">
          <RecoverySimulator
            initialSubjectId={summary.worst.subjectId}
            subjects={summary.subjects.map((s) => {
              const sub = db.subjects.find((x) => x.id === s.subjectId)!
              return { id: s.subjectId, code: sub.code, name: sub.name, held: s.held, attended: s.attended }
            })}
          />

          <Card className="gap-0 p-0">
            <h2 className="border-b p-4 font-semibold">Intervention history</h2>
            {interventions.length === 0 ? (
              <p className="p-4 text-sm text-muted-foreground">No interventions logged yet.</p>
            ) : (
              <ol className="divide-y">
                {interventions.map((i) => (
                  <li key={i.id} className="flex flex-col gap-1 p-4 text-sm">
                    <div className="flex items-center justify-between text-xs text-muted-foreground">
                      <span>{new Date(i.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</span>
                      <span>{i.subjectId ? db.subjects.find((s) => s.id === i.subjectId)?.code : 'General'}</span>
                    </div>
                    <p className="text-pretty">{i.note}</p>
                    {i.actionPlan && <p className="text-pretty text-muted-foreground"><span className="font-medium text-foreground">Plan:</span> {i.actionPlan}</p>}
                    {i.followUp && (
                      <p className="inline-flex items-center gap-1 text-xs text-primary">
                        <CalendarClock className="size-3" aria-hidden="true" /> Follow-up {i.followUp}
                      </p>
                    )}
                  </li>
                ))}
              </ol>
            )}
          </Card>

          <Card className="gap-0 p-0">
            <h2 className="border-b p-4 font-semibold">Alerts & leave</h2>
            <ul className="divide-y text-sm">
              {emails.map((e) => (
                <li key={e.id} className="flex items-start gap-2 p-4">
                  <Mail className="mt-0.5 size-4 shrink-0 text-muted-foreground" aria-hidden="true" />
                  <div>
                    <p className="font-medium">{e.trigger === 'auto' ? 'Automatic critical alert' : 'Manual alert'}</p>
                    <p className="text-xs text-muted-foreground">{new Date(e.createdAt).toLocaleString('en-IN')}</p>
                  </div>
                </li>
              ))}
              {leaves.map((l) => (
                <li key={l.id} className="flex items-start gap-2 p-4">
                  <CalendarClock className="mt-0.5 size-4 shrink-0 text-muted-foreground" aria-hidden="true" />
                  <div>
                    <p className="font-medium">Medical leave {l.from} to {l.to}</p>
                    <p className="text-xs capitalize text-muted-foreground">{l.status}</p>
                  </div>
                </li>
              ))}
              {emails.length === 0 && leaves.length === 0 && <li className="p-4 text-muted-foreground">Nothing yet.</li>}
            </ul>
          </Card>
        </div>
      </div>
    </>
  )
}
