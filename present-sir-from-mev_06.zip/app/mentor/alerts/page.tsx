import Link from 'next/link'
import { AlertOctagon, Inbox, Mail, TriangleAlert } from 'lucide-react'
import { getDb } from '@/lib/db'
import { formatPct, summarizeAll, type StudentSummary } from '@/lib/attendance'
import { Card } from '@/components/ui/card'
import { PageHeader } from '@/components/page-header'
import { RiskBadge, tierTextClass } from '@/components/risk-badge'
import { SendAlertButton, SendAllCriticalButton } from '@/components/send-alert-button'
import { cn } from '@/lib/utils'

export const metadata = { title: 'Notification Hub' }

export default function AlertsPage() {
  const db = getDb()
  const summaries = summarizeAll(db).sort((a, b) => a.worst.pct - b.worst.pct)
  const critical = summaries.filter((s) => s.tier === 'critical')
  const warning = summaries.filter((s) => s.tier === 'warning')
  const lastContact = new Map<string, string>()
  for (const i of db.interventions) if (!lastContact.has(i.studentId)) lastContact.set(i.studentId, i.createdAt)
  const code = (id: string) => db.subjects.find((s) => s.id === id)?.code ?? ''

  function AlertGroup({ title, icon: Icon, list, tone }: { title: string; icon: typeof AlertOctagon; list: StudentSummary[]; tone: string }) {
    return (
      <Card className="gap-0 p-0">
        <div className="flex items-center gap-2 border-b p-4">
          <Icon className={cn('size-5', tone)} aria-hidden="true" />
          <h2 className="font-semibold">{title}</h2>
          <span className="ml-auto text-xs text-muted-foreground">{list.length} students</span>
        </div>
        {list.length === 0 ? (
          <p className="p-4 text-sm text-muted-foreground">No students in this tier.</p>
        ) : (
          <ul className="divide-y">
            {list.map((s) => {
              const risky = s.subjects.filter((x) => x.tier !== 'safe').sort((a, b) => a.pct - b.pct)
              const contacted = lastContact.get(s.student.id)
              return (
                <li key={s.student.id} className="flex flex-col gap-3 p-4 md:flex-row md:items-center">
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <Link href={`/mentor/students/${s.student.id}`} className="font-medium hover:text-primary hover:underline">
                        {s.student.name}
                      </Link>
                      <span className="font-mono text-xs text-muted-foreground">{s.student.roll}</span>
                      <RiskBadge tier={s.tier} />
                    </div>
                    <p className="mt-1 text-pretty text-sm">
                      <span className="font-medium">Action:</span> attend next{' '}
                      <strong className={tierTextClass(s.tier)}>{s.worst.needed}</strong> {code(s.worst.subjectId)} classes consecutively.
                    </p>
                    <div className="mt-1.5 flex flex-wrap gap-1.5">
                      {risky.map((x) => (
                        <span key={x.subjectId} className="rounded bg-muted px-1.5 py-0.5 font-mono text-xs">
                          {code(x.subjectId)} <span className={tierTextClass(x.tier)}>{formatPct(x.pct)}</span> {'·'} +{x.needed}
                        </span>
                      ))}
                    </div>
                    <p className="mt-1.5 text-xs text-muted-foreground">
                      {contacted ? `Last counselled ${new Date(contacted).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}` : 'Not yet counselled'}
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <SendAlertButton studentId={s.student.id} size="sm" />
                    <Link
                      href={`/mentor/students/${s.student.id}#log-intervention`}
                      className="inline-flex h-8 items-center rounded-lg bg-primary px-3 text-sm font-medium text-primary-foreground hover:bg-primary/90"
                    >
                      Counsel
                    </Link>
                  </div>
                </li>
              )
            })}
          </ul>
        )}
      </Card>
    )
  }

  return (
    <>
      <PageHeader
        title="Mentor Notification Hub"
        description="Actionable list of at-risk students for proactive mentoring, plus the simulated email outbox."
        actions={<SendAllCriticalButton count={critical.length} />}
      />

      <div className="grid gap-6 xl:grid-cols-[1fr_400px]">
        <div className="flex flex-col gap-6">
          <AlertGroup title="Critical - below 65%" icon={AlertOctagon} list={critical} tone="text-critical" />
          <AlertGroup title="Warning - 65 to 74%" icon={TriangleAlert} list={warning} tone="text-warning" />
        </div>

        <Card className="h-fit gap-0 p-0">
          <div className="flex items-center gap-2 border-b p-4">
            <Inbox className="size-5 text-primary" aria-hidden="true" />
            <h2 className="font-semibold">Email outbox (simulated)</h2>
            <span className="ml-auto text-xs text-muted-foreground">{db.emails.length}</span>
          </div>
          {db.emails.length === 0 ? (
            <p className="p-4 text-pretty text-sm text-muted-foreground">
              No alerts sent yet. Mark a student absent so they drop below 65%, or use the buttons on the left.
            </p>
          ) : (
            <ul className="max-h-[720px] divide-y overflow-y-auto">
              {db.emails.slice(0, 50).map((e) => (
                <li key={e.id}>
                  <details className="group p-4">
                    <summary className="flex cursor-pointer list-none items-start gap-2">
                      <Mail className="mt-0.5 size-4 shrink-0 text-muted-foreground" aria-hidden="true" />
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-sm font-medium">{e.subject}</span>
                        <span className="block truncate text-xs text-muted-foreground">To: {e.to.join(', ')}</span>
                      </span>
                      <span
                        className={cn(
                          'shrink-0 rounded px-1.5 py-0.5 text-[10px] font-semibold uppercase',
                          e.trigger === 'auto' ? 'bg-critical-soft text-critical' : 'bg-muted text-muted-foreground',
                        )}
                      >
                        {e.trigger}
                      </span>
                    </summary>
                    <pre className="mt-3 whitespace-pre-wrap rounded-lg bg-muted p-3 font-sans text-xs leading-relaxed">{e.body}</pre>
                    <p className="mt-2 text-xs text-muted-foreground">{new Date(e.createdAt).toLocaleString('en-IN')}</p>
                  </details>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>
    </>
  )
}
