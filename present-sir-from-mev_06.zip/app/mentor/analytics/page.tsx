import { getDb } from '@/lib/db'
import { summarizeAll } from '@/lib/attendance'
import { PageHeader } from '@/components/page-header'
import { CorrelationChart, type CorrPoint } from '@/components/correlation-chart'

export const metadata = { title: 'Attendance Correlation' }

export default function AnalyticsPage() {
  const db = getDb()
  const summaries = summarizeAll(db)
  const marks = new Map(db.midterms.map((m) => [`${m.studentId}|${m.subjectId}`, m.marks]))
  const points: CorrPoint[] = summaries.flatMap((s) =>
    s.subjects
      .filter((x) => marks.has(`${s.student.id}|${x.subjectId}`))
      .map((x) => ({
        studentId: s.student.id,
        name: s.student.name,
        subjectId: x.subjectId,
        pct: x.pct,
        marks: marks.get(`${s.student.id}|${x.subjectId}`)!,
      })),
  )

  return (
    <>
      <PageHeader
        title="Subject-wise Correlation"
        description="Does attendance predict performance? Midterm test marks plotted against attendance percentage."
      />
      <CorrelationChart points={points} subjects={db.subjects.map(({ id, code, name }) => ({ id, code, name }))} />
    </>
  )
}
