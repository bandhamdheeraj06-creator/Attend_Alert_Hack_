import { PageHeader } from '@/components/page-header'
import { CsvImporter } from '@/components/csv-importer'

export const metadata = { title: 'CSV Import' }

export default function ImportPage() {
  return (
    <>
      <PageHeader
        title="CSV Roster & Log Importer"
        description="Upload class rosters and biometric attendance dumps. Percentages and risk tiers recalculate instantly."
      />
      <CsvImporter />
    </>
  )
}
