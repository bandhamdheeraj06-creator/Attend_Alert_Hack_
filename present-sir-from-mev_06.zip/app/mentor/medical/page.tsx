import Link from 'next/link'
import { FileText } from 'lucide-react'
import { getDb } from '@/lib/db'
import { formatPct, summarizeStudent } from '@/lib/attendance'
import { Card } from '@/components/ui/card'
import { PageHeader } from '@/components/page-header'
import { LeaveReview } from '@/components/leave-review'
import { RiskBadge } from '@/components/risk-badge'
import type { DB, MedicalLeave } from '@/lib/types'
import { cn } from '@/lib/utils'

export const metadata = { title: 'Medical Leave' }

function impactOf(db: DB, leave: MedicalLeave) {
  const student = db.students.find((s) => s.id === leave.studentId)!
  const before = summarizeStudent(db, student)
  const simulated: DB = { ...db, leaves: db.leaves.map((l) => (l.id === leave.id ? { ...l, status: 'approved' as const } : l)) }
  const after = summarizeStudent(simulated, student)
  const changes = after.subjects
    .map((s, i) => ({ code: db.subjects.find((x) => x.id === s.subjectId)?.code, from: before.subjects[i].pct, to: s.pct, exempt: s.exempt - before.subjects[i].exempt }))
    .filter((c) => c.exempt > 0)
  return { before, after, changes }
}

export default function MedicalPage() {
  const db = getDb()
  const pending = db.leaves.filter((l) => l.status === 'pending')
  const reviewed = db.leaves.filter((l) => l.status !== 'pending')

  return (
    <>
      <PageHeader
        title="Medical Leave Exemptions"
        description="Approved certificates exclude absences in the date range from classes held, then attendance is recalculated."
      />

      <Card className="gap-0 p-0">
        <h2 className="border-b p-4 font-semibold">Pending review ({pending.length})</h2>
        {pending.length === 0 ? (
          <p className="p-4 text-sm text-muted-foreground">No pending requests. Students submit leave from their portal.</p>
        ) : (
          <ul className="divide-y">
            {pending.map((l) => {
              const student = db.students.find((s) => s.id === l.studentId)!
              const { before, after, changes } = impactOf(db, l)
              const impact = changes.length
                ? `If approved: ${changes.map((c) => `${c.code} ${formatPct(c.from)} -> ${formatPct(c.to)} (${c.exempt} absence${c.exempt > 1 ? 's' : ''} exempted)`).join(', ')}`
                : 'No recorded absences fall in this date range.'
              return (
                <li key={l.id} className="flex flex-col gap-3 p-4">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div>
                      <div className="flex flex-wrap items-center gap-2">
                        <Link href={`/mentor/students/${student.id}`} className="font-medium hover:underline">{student.name}</Link>
                        <span className="font-mono text-xs text-muted-foreground">{student.roll}</span>
                        <RiskBadge tier={before.tier} />
                        {after.tier !== before.tier && (
                          <>
                            <span className="text-xs text-muted-foreground">{'->'}</span>
                            <RiskBadge tier={after.tier} />
                          </>
                        )}
                      </div>
                      <p className="mt-1 text-sm">
                        <span className="font-medium">{l.from}</span> to <span className="font-medium">{l.to}</span> {'·'} {l.reason}
                      </p>
                    </div>
                    {l.fileDataUrl ? (
                      <a href={l.fileDataUrl} download={l.fileName} className="inline-flex items-center gap-1.5 rounded-md bg-muted px-2.5 py-1.5 text-xs font-medium hover:bg-accent">
                        <FileText className="size-3.5" aria-hidden="true" /> {l.fileName}
                      </a>
                    ) : (
                      <span className="inline-flex items-center gap-1.5 rounded-md bg-muted px-2.5 py-1.5 text-xs font-medium">
                        <FileText className="size-3.5" aria-hidden="true" /> {l.fileName}
                      </span>
                    )}
                  </div>
                  <LeaveReview leaveId={l.id} impact={impact} />
                </li>
              )
            })}
          </ul>
        )}
      </Card>

      <Card className="gap-0 p-0">
        <h2 className="border-b p-4 font-semibold">Reviewed</h2>
        {reviewed.length === 0 ? (
          <p className="p-4 text-sm text-muted-foreground">Nothing reviewed yet.</p>
        ) : (
          <ul className="divide-y text-sm">
            {reviewed.map((l) => {
              const student = db.students.find((s) => s.id === l.studentId)!
              return (
                <li key={l.id} className="flex flex-wrap items-center gap-3 p-4">
                  <span className="font-medium">{student.name}</span>
                  <span className="text-muted-foreground">{l.from} to {l.to}</span>
                  <span
                    className={cn(
                      'rounded-full px-2 py-0.5 text-xs font-semibold capitalize',
                      l.status === 'approved' ? 'bg-safe-soft text-safe' : 'bg-critical-soft text-critical',
                    )}
                  >
                    {l.status}
                  </span>
                  {l.reviewNote && <span className="text-xs text-muted-foreground">{l.reviewNote}</span>}
                </li>
              )
            })}
          </ul>
        )}
      </Card>
    </>
  )
}
