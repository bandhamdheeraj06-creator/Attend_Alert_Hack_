'use client'

import Link from 'next/link'
import { useMemo, useState, useTransition } from 'react'
import { AlertOctagon, CheckCheck, Loader2, Mail, Save, Search, UserX } from 'lucide-react'
import { saveAttendance, type SaveAttendanceResult } from '@/app/actions'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { RiskBadge, tierTextClass } from '@/components/risk-badge'
import { classesNeeded, formatPct, percentage, tierFor, type Tier } from '@/lib/attendance'
import type { Status } from '@/lib/types'
import { cn } from '@/lib/utils'

export interface SheetStudent {
  id: string
  roll: string
  name: string
  /** per subject: held/attended excluding the selected date's session */
  base: Record<string, { held: number; attended: number }>
}

const STATUS_OPTIONS: { value: Status; label: string; short: string; active: string }[] = [
  { value: 'P', label: 'Present', short: 'P', active: 'bg-safe text-white ring-safe' },
  { value: 'L', label: 'Late', short: 'L', active: 'bg-warning text-white ring-warning' },
  { value: 'A', label: 'Absent', short: 'A', active: 'bg-critical text-white ring-critical' },
]

export function AttendanceSheet({
  students,
  subjects,
  existing,
  defaultDate,
}: {
  students: SheetStudent[]
  subjects: { id: string; code: string; name: string; faculty: string }[]
  /** key `${subjectId}|${date}` -> studentId -> status */
  existing: Record<string, Record<string, Status>>
  defaultDate: string
}) {
  const [subjectId, setSubjectId] = useState(subjects[0]?.id ?? '')
  const [date, setDate] = useState(defaultDate)
  const [query, setQuery] = useState('')
  const [overrides, setOverrides] = useState<Record<string, Record<string, Status>>>({})
  const [result, setResult] = useState<SaveAttendanceResult | null>(null)
  const [pending, startTransition] = useTransition()

  const key = `${subjectId}|${date}`
  const saved = existing[key]
  const marks: Record<string, Status> = useMemo(() => {
    const base: Record<string, Status> = {}
    for (const s of students) base[s.id] = saved?.[s.id] ?? 'P'
    return { ...base, ...overrides[key] }
  }, [students, saved, overrides, key])

  const setMark = (studentId: string, status: Status) => {
    setResult(null)
    setOverrides((prev) => ({ ...prev, [key]: { ...prev[key], [studentId]: status } }))
  }
  const markAll = (status: Status) => {
    setResult(null)
    setOverrides((prev) => ({ ...prev, [key]: Object.fromEntries(students.map((s) => [s.id, status])) }))
  }

  const counts = useMemo(() => {
    const values = Object.values(marks)
    return { P: values.filter((v) => v === 'P').length, L: values.filter((v) => v === 'L').length, A: values.filter((v) => v === 'A').length }
  }, [marks])

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase()
    return q ? students.filter((s) => s.name.toLowerCase().includes(q) || s.roll.toLowerCase().includes(q)) : students
  }, [students, query])

  const project = (s: SheetStudent) => {
    const base = s.base[subjectId] ?? { held: 0, attended: 0 }
    const held = base.held + 1
    const attended = base.attended + (marks[s.id] === 'A' ? 0 : 1)
    const pct = percentage(held, attended)
    const prevPct = percentage(base.held, base.attended)
    return { pct, tier: tierFor(pct) as Tier, prevTier: tierFor(prevPct) as Tier, needed: classesNeeded(held, attended), held, attended }
  }

  const willTurnCritical = students.filter((s) => {
    const p = project(s)
    return p.tier === 'critical' && p.prevTier !== 'critical'
  })

  function onSave() {
    startTransition(async () => {
      const res = await saveAttendance({ subjectId, date, marks })
      setResult(res)
      if (res.ok) setOverrides((prev) => ({ ...prev, [key]: {} }))
    })
  }

  const subject = subjects.find((s) => s.id === subjectId)

  return (
    <div className="flex flex-col gap-4">
      <Card className="gap-4 p-4">
        <div className="grid gap-3 sm:grid-cols-[2fr_1fr]">
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="sheet-subject">Subject</Label>
            <select
              id="sheet-subject"
              value={subjectId}
              onChange={(e) => {
                setSubjectId(e.target.value)
                setResult(null)
              }}
              className="h-10 rounded-lg border border-input bg-card px-3 text-sm"
            >
              {subjects.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.code} {'-'} {s.name} ({s.faculty})
                </option>
              ))}
            </select>
          </div>
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="sheet-date">Class date</Label>
            <Input
              id="sheet-date"
              type="date"
              value={date}
              onChange={(e) => {
                if (e.target.value) setDate(e.target.value)
                setResult(null)
              }}
              className="h-10"
            />
          </div>
        </div>
        <p className="text-xs text-muted-foreground">
          {saved
            ? 'A session already exists for this date - saving will update it.'
            : 'New session. Everyone defaults to Present - just tap the absentees.'}
        </p>
      </Card>

      <div className="sticky top-[104px] z-20 lg:top-0">
        <Card className="flex-col gap-3 p-3 shadow-md sm:flex-row sm:items-center">
          <div className="flex flex-wrap items-center gap-2">
            <Button variant="outline" onClick={() => markAll('P')}>
              <CheckCheck className="size-4 text-safe" aria-hidden="true" />
              Mark all present
            </Button>
            <Button variant="outline" onClick={() => markAll('A')}>
              <UserX className="size-4 text-critical" aria-hidden="true" />
              Mark all absent
            </Button>
          </div>
          <div className="flex items-center gap-3 text-sm tabular-nums sm:ml-auto" aria-live="polite">
            <span><span className="font-semibold text-safe">{counts.P}</span> P</span>
            <span><span className="font-semibold text-warning">{counts.L}</span> L</span>
            <span><span className="font-semibold text-critical">{counts.A}</span> A</span>
          </div>
          <Button size="lg" onClick={onSave} disabled={pending} className="sm:w-auto">
            {pending ? <Loader2 className="size-4 animate-spin" aria-hidden="true" /> : <Save className="size-4" aria-hidden="true" />}
            Save {subject?.code} attendance
          </Button>
        </Card>
      </div>

      {willTurnCritical.length > 0 && !result && (
        <p className="flex items-start gap-2 rounded-lg border border-warning/30 bg-warning-soft px-3 py-2 text-sm text-warning">
          <AlertOctagon className="mt-0.5 size-4 shrink-0" aria-hidden="true" />
          Saving will push {willTurnCritical.map((s) => s.name).join(', ')} into the Critical tier and send automatic alert emails.
        </p>
      )}

      {result && (
        <div
          role="status"
          className={cn(
            'rounded-xl border p-4 text-sm',
            !result.ok
              ? 'border-critical/30 bg-critical-soft text-critical'
              : result.newlyCritical?.length
                ? 'border-critical/30 bg-critical-soft'
                : 'border-safe/30 bg-safe-soft',
          )}
        >
          {!result.ok ? (
            result.error
          ) : (
            <>
              <p className="font-semibold">
                Saved {subject?.code} for {result.sessionDate}: {result.counts?.present} present, {result.counts?.late} late, {result.counts?.absent} absent.
              </p>
              {result.newlyCritical && result.newlyCritical.length > 0 ? (
                <div className="mt-2 flex flex-col gap-2">
                  <p className="flex items-center gap-2 font-semibold text-critical">
                    <AlertOctagon className="size-4" aria-hidden="true" />
                    Critical shortage alert triggered for {result.newlyCritical.length} student{result.newlyCritical.length > 1 ? 's' : ''}
                  </p>
                  <ul className="flex flex-col gap-1">
                    {result.newlyCritical.map((s) => (
                      <li key={s.id} className="flex flex-wrap items-center gap-x-2">
                        <Link href={`/mentor/students/${s.id}`} className="font-medium underline underline-offset-2">
                          {s.name}
                        </Link>
                        <span className="font-mono text-critical">{formatPct(s.pct)}</span>
                        <span className="text-muted-foreground">needs {s.needed} consecutive classes</span>
                        <span className="inline-flex items-center gap-1 text-xs text-muted-foreground">
                          <Mail className="size-3" aria-hidden="true" /> email sent to student and parent
                        </span>
                      </li>
                    ))}
                  </ul>
                  <Link href="/mentor/alerts" className="text-sm font-medium text-primary underline underline-offset-2">
                    View in Notification Hub
                  </Link>
                </div>
              ) : (
                <p className="mt-1 text-muted-foreground">No new critical shortages.</p>
              )}
            </>
          )}
        </div>
      )}

      <Card className="gap-0 p-0">
        <div className="flex items-center gap-3 border-b p-3">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute left-2.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Filter by name or roll no."
              aria-label="Filter students"
              className="h-9 pl-8"
            />
          </div>
          <span className="text-xs text-muted-foreground">{visible.length} students</span>
        </div>
        <ul className="divide-y">
          {visible.map((s, i) => {
            const p = project(s)
            const status = marks[s.id]
            return (
              <li
                key={s.id}
                className={cn(
                  'flex flex-col gap-3 px-4 py-3 sm:flex-row sm:items-center',
                  status === 'A' && 'bg-critical-soft/50',
                )}
              >
                <div className="flex flex-1 items-center gap-3">
                  <span className="w-6 text-right font-mono text-xs text-muted-foreground">{i + 1}</span>
                  <div className="min-w-0">
                    <p className="truncate font-medium">{s.name}</p>
                    <p className="font-mono text-xs text-muted-foreground">{s.roll}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 pl-9 sm:pl-0">
                  <div className="flex w-40 flex-col items-start text-xs sm:items-end">
                    <span className="flex items-center gap-1.5">
                      <span className="text-muted-foreground">After save</span>
                      <span className={cn('font-mono font-semibold tabular-nums', tierTextClass(p.tier))}>{formatPct(p.pct)}</span>
                    </span>
                    {p.tier !== p.prevTier ? (
                      <RiskBadge tier={p.tier} className="mt-0.5" />
                    ) : (
                      <span className="text-muted-foreground tabular-nums">{p.attended}/{p.held} classes</span>
                    )}
                  </div>
                  <div role="radiogroup" aria-label={`Attendance for ${s.name}`} className="flex gap-1">
                    {STATUS_OPTIONS.map((opt) => (
                      <button
                        key={opt.value}
                        type="button"
                        role="radio"
                        aria-checked={status === opt.value}
                        aria-label={opt.label}
                        title={opt.label}
                        onClick={() => setMark(s.id, opt.value)}
                        className={cn(
                          'flex size-9 items-center justify-center rounded-lg text-sm font-semibold ring-1 ring-inset transition-colors',
                          status === opt.value ? opt.active : 'bg-card text-muted-foreground ring-border hover:bg-muted',
                        )}
                      >
                        {opt.short}
                      </button>
                    ))}
                  </div>
                </div>
              </li>
            )
          })}
        </ul>
      </Card>
    </div>
  )
}
