import { cn } from '@/lib/utils'
import { TIER_LABEL, type Tier } from '@/lib/attendance'

const STYLES: Record<Tier, string> = {
  safe: 'bg-safe-soft text-safe ring-safe/25',
  warning: 'bg-warning-soft text-warning ring-warning/30',
  critical: 'bg-critical-soft text-critical ring-critical/25',
}

const DOT: Record<Tier, string> = {
  safe: 'bg-safe',
  warning: 'bg-warning',
  critical: 'bg-critical',
}

export function RiskBadge({ tier, className }: { tier: Tier; className?: string }) {
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-xs font-semibold ring-1 ring-inset whitespace-nowrap',
        STYLES[tier],
        className,
      )}
    >
      <span className={cn('size-1.5 rounded-full', DOT[tier])} aria-hidden="true" />
      {TIER_LABEL[tier]}
    </span>
  )
}

export function tierTextClass(tier: Tier) {
  return tier === 'safe' ? 'text-safe' : tier === 'warning' ? 'text-warning' : 'text-critical'
}

export function tierBarClass(tier: Tier) {
  return tier === 'safe' ? 'bg-safe' : tier === 'warning' ? 'bg-warning' : 'bg-critical'
}

export function AttendanceBar({ pct, tier, className }: { pct: number; tier: Tier; className?: string }) {
  return (
    <div className={cn('relative h-2 w-full overflow-hidden rounded-full bg-muted', className)}>
      <div className={cn('h-full rounded-full', tierBarClass(tier))} style={{ width: `${Math.min(100, pct)}%` }} />
      <div className="absolute inset-y-0 w-px bg-foreground/40" style={{ left: '75%' }} aria-hidden="true" />
    </div>
  )
}
