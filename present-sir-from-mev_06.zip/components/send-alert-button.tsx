'use client'

import { useState, useTransition } from 'react'
import { Check, Loader2, Mail, Send } from 'lucide-react'
import { sendAlertEmail, sendAllCriticalAlerts } from '@/app/actions'
import { Button } from '@/components/ui/button'

export function SendAlertButton({ studentId, size = 'default' }: { studentId: string; size?: 'default' | 'sm' | 'lg' }) {
  const [pending, startTransition] = useTransition()
  const [sent, setSent] = useState(false)
  return (
    <Button
      variant="outline"
      size={size}
      disabled={pending}
      onClick={() =>
        startTransition(async () => {
          const res = await sendAlertEmail(studentId)
          setSent(res.ok)
        })
      }
    >
      {pending ? (
        <Loader2 className="size-4 animate-spin" aria-hidden="true" />
      ) : sent ? (
        <Check className="size-4 text-safe" aria-hidden="true" />
      ) : (
        <Mail className="size-4" aria-hidden="true" />
      )}
      {sent ? 'Alert sent' : 'Email student & parent'}
    </Button>
  )
}

export function SendAllCriticalButton({ count }: { count: number }) {
  const [pending, startTransition] = useTransition()
  const [sent, setSent] = useState<number | null>(null)
  return (
    <Button
      size="lg"
      disabled={pending || count === 0}
      className="bg-critical text-white hover:bg-critical/90"
      onClick={() =>
        startTransition(async () => {
          const res = await sendAllCriticalAlerts()
          setSent(res.sent)
        })
      }
    >
      {pending ? <Loader2 className="size-4 animate-spin" aria-hidden="true" /> : <Send className="size-4" aria-hidden="true" />}
      {sent !== null ? `Sent ${sent} alerts` : `Email all ${count} critical`}
    </Button>
  )
}
