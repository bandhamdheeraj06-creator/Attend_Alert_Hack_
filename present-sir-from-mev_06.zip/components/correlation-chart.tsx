'use client'

import { useMemo, useState } from 'react'
import { CartesianGrid, ReferenceLine, ResponsiveContainer, Scatter, ScatterChart, Tooltip, XAxis, YAxis, ZAxis } from 'recharts'
import { Card } from '@/components/ui/card'
import { Label } from '@/components/ui/label'
import { formatPct, tierFor, type Tier } from '@/lib/attendance'

export interface CorrPoint {
  studentId: string
  name: string
  subjectId: string
  pct: number
  marks: number
}

const TIER_COLOR: Record<Tier, string> = {
  safe: 'var(--safe)',
  warning: 'var(--warning)',
  critical: 'var(--critical)',
}

function pearson(points: { x: number; y: number }[]) {
  const n = points.length
  if (n < 2) return 0
  const mx = points.reduce((a, p) => a + p.x, 0) / n
  const my = points.reduce((a, p) => a + p.y, 0) / n
  let num = 0
  let dx = 0
  let dy = 0
  for (const p of points) {
    num += (p.x - mx) * (p.y - my)
    dx += (p.x - mx) ** 2
    dy += (p.y - my) ** 2
  }
  return dx && dy ? num / Math.sqrt(dx * dy) : 0
}

export function CorrelationChart({ points, subjects }: { points: CorrPoint[]; subjects: { id: string; code: string; name: string }[] }) {
  const [subjectId, setSubjectId] = useState('all')

  const data = useMemo(
    () =>
      points
        .filter((p) => subjectId === 'all' || p.subjectId === subjectId)
        .map((p) => ({ ...p, x: Math.round(p.pct * 10) / 10, y: p.marks, tier: tierFor(p.pct) })),
    [points, subjectId],
  )
  const r = pearson(data)
  const groups = (['critical', 'warning', 'safe'] as Tier[]).map((t) => ({ tier: t, data: data.filter((d) => d.tier === t) }))
  const avgMarks = (t: Tier) => {
    const g = data.filter((d) => d.tier === t)
    return g.length ? (g.reduce((a, d) => a + d.y, 0) / g.length).toFixed(1) : '-'
  }

  return (
    <div className="grid gap-6 xl:grid-cols-[1fr_300px]">
      <Card className="gap-4 p-4 sm:p-5">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <h2 className="font-semibold">Attendance vs midterm marks</h2>
            <p className="text-xs text-muted-foreground">Each dot is one student in one subject. Midterm out of 30.</p>
          </div>
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="corr-subject" className="text-xs">Subject</Label>
            <select
              id="corr-subject"
              value={subjectId}
              onChange={(e) => setSubjectId(e.target.value)}
              className="h-9 rounded-lg border border-input bg-card px-2.5 text-sm"
            >
              <option value="all">All subjects</option>
              {subjects.map((s) => (
                <option key={s.id} value={s.id}>{s.code} {s.name}</option>
              ))}
            </select>
          </div>
        </div>
        <div className="h-[380px] w-full" role="img" aria-label={`Scatter plot of attendance against midterm marks, correlation ${r.toFixed(2)}`}>
          <ResponsiveContainer width="100%" height="100%">
            <ScatterChart margin={{ top: 10, right: 16, bottom: 24, left: 0 }}>
              <CartesianGrid stroke="var(--border)" strokeDasharray="3 3" />
              <XAxis
                type="number"
                dataKey="x"
                name="Attendance"
                domain={[30, 100]}
                unit="%"
                tick={{ fontSize: 12, fill: 'var(--muted-foreground)' }}
                label={{ value: 'Attendance %', position: 'insideBottom', offset: -12, fontSize: 12, fill: 'var(--muted-foreground)' }}
              />
              <YAxis
                type="number"
                dataKey="y"
                name="Midterm"
                domain={[0, 30]}
                tick={{ fontSize: 12, fill: 'var(--muted-foreground)' }}
                width={36}
              />
              <ZAxis range={[60, 60]} />
              <ReferenceLine x={75} stroke="var(--foreground)" strokeDasharray="4 4" label={{ value: '75%', position: 'top', fontSize: 11, fill: 'var(--foreground)' }} />
              <ReferenceLine x={65} stroke="var(--critical)" strokeDasharray="2 4" />
              <Tooltip
                cursor={{ strokeDasharray: '3 3' }}
                content={({ active, payload }) => {
                  if (!active || !payload?.length) return null
                  const p = payload[0].payload as (typeof data)[number]
                  return (
                    <div className="rounded-lg border bg-card px-3 py-2 text-xs shadow-md">
                      <p className="font-medium">{p.name}</p>
                      <p className="text-muted-foreground">{subjects.find((s) => s.id === p.subjectId)?.code}</p>
                      <p>Attendance {formatPct(p.pct)} {'·'} Midterm {p.y}/30</p>
                    </div>
                  )
                }}
              />
              {groups.map((g) => (
                <Scatter key={g.tier} name={g.tier} data={g.data} fill={TIER_COLOR[g.tier]} fillOpacity={0.75} />
              ))}
            </ScatterChart>
          </ResponsiveContainer>
        </div>
      </Card>

      <Card className="h-fit gap-4 p-5">
        <div>
          <p className="text-xs text-muted-foreground">Pearson correlation (r)</p>
          <p className="font-mono text-4xl font-semibold tabular-nums text-primary">{r.toFixed(2)}</p>
          <p className="mt-1 text-pretty text-sm text-muted-foreground">
            {r > 0.6 ? 'Strong positive' : r > 0.3 ? 'Moderate positive' : 'Weak'} relationship: students who attend more score higher on midterms.
          </p>
        </div>
        <ul className="flex flex-col gap-2 text-sm">
          {(['safe', 'warning', 'critical'] as Tier[]).map((t) => (
            <li key={t} className="flex items-center justify-between">
              <span className="flex items-center gap-2 capitalize">
                <span className="size-2.5 rounded-full" style={{ background: TIER_COLOR[t] }} aria-hidden="true" />
                {t}
              </span>
              <span className="tabular-nums text-muted-foreground">avg <span className="font-semibold text-foreground">{avgMarks(t)}</span>/30</span>
            </li>
          ))}
        </ul>
      </Card>
    </div>
  )
}
