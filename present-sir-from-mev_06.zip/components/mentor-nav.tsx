'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import {
  BellRing,
  ClipboardCheck,
  FileHeart,
  LayoutDashboard,
  LogOut,
  ScatterChart,
  Upload,
} from 'lucide-react'
import { logout } from '@/app/actions'
import { Brand } from '@/components/brand'
import { cn } from '@/lib/utils'

const LINKS = [
  { href: '/mentor', label: 'Dashboard', icon: LayoutDashboard },
  { href: '/mentor/attendance', label: 'Mark Attendance', icon: ClipboardCheck },
  { href: '/mentor/alerts', label: 'Notification Hub', icon: BellRing, badge: 'critical' as const },
  { href: '/mentor/medical', label: 'Medical Leave', icon: FileHeart, badge: 'leaves' as const },
  { href: '/mentor/analytics', label: 'Correlation', icon: ScatterChart },
  { href: '/mentor/import', label: 'CSV Import', icon: Upload },
]

export function MentorNav({
  mentor,
  counts,
}: {
  mentor: { name: string; designation: string }
  counts: { critical: number; leaves: number }
}) {
  const pathname = usePathname()
  const isActive = (href: string) => (href === '/mentor' ? pathname === href || pathname.startsWith('/mentor/students') : pathname.startsWith(href))

  return (
    <>
      <aside className="sticky top-0 hidden h-dvh w-64 shrink-0 flex-col bg-sidebar text-sidebar-foreground lg:flex">
        <div className="px-5 py-6">
          <Brand inverted />
        </div>
        <nav aria-label="Mentor" className="flex flex-1 flex-col gap-1 px-3">
          {LINKS.map(({ href, label, icon: Icon, badge }) => {
            const count = badge ? counts[badge] : 0
            return (
              <Link
                key={href}
                href={href}
                aria-current={isActive(href) ? 'page' : undefined}
                className={cn(
                  'flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors',
                  isActive(href)
                    ? 'bg-sidebar-accent text-sidebar-accent-foreground'
                    : 'text-sidebar-foreground/70 hover:bg-sidebar-accent/60 hover:text-sidebar-accent-foreground',
                )}
              >
                <Icon className="size-4" aria-hidden="true" />
                <span className="flex-1">{label}</span>
                {count > 0 && (
                  <span
                    className={cn(
                      'rounded-full px-1.5 py-0.5 text-[10px] font-semibold',
                      badge === 'critical' ? 'bg-critical text-white' : 'bg-sidebar-primary text-sidebar-primary-foreground',
                    )}
                  >
                    {count}
                  </span>
                )}
              </Link>
            )
          })}
        </nav>
        <div className="border-t border-sidebar-border p-4">
          <p className="text-sm font-medium text-white">{mentor.name}</p>
          <p className="text-xs text-sidebar-foreground/60">{mentor.designation}</p>
          <form action={logout} className="mt-3">
            <button
              type="submit"
              className="flex items-center gap-2 text-xs text-sidebar-foreground/70 hover:text-white"
            >
              <LogOut className="size-3.5" aria-hidden="true" />
              Sign out
            </button>
          </form>
        </div>
      </aside>

      <header className="sticky top-0 z-30 border-b bg-sidebar text-sidebar-foreground lg:hidden">
        <div className="flex items-center justify-between px-4 py-3">
          <Brand inverted />
          <form action={logout}>
            <button type="submit" className="flex items-center gap-1.5 text-xs text-sidebar-foreground/80">
              <LogOut className="size-3.5" aria-hidden="true" />
              Sign out
            </button>
          </form>
        </div>
        <nav aria-label="Mentor" className="flex gap-1 overflow-x-auto px-3 pb-3">
          {LINKS.map(({ href, label, icon: Icon }) => (
            <Link
              key={href}
              href={href}
              aria-current={isActive(href) ? 'page' : undefined}
              className={cn(
                'flex shrink-0 items-center gap-1.5 rounded-md px-2.5 py-1.5 text-xs font-medium',
                isActive(href) ? 'bg-sidebar-accent text-white' : 'text-sidebar-foreground/70',
              )}
            >
              <Icon className="size-3.5" aria-hidden="true" />
              {label}
            </Link>
          ))}
        </nav>
      </header>
    </>
  )
}
