'use client'

import { useState } from 'react'
import { Calculator } from 'lucide-react'
import { Card } from '@/components/ui/card'
import { Label } from '@/components/ui/label'
import { AttendanceBar, RiskBadge, tierTextClass } from '@/components/risk-badge'
import { classesNeeded, formatPct, percentage, tierFor } from '@/lib/attendance'
import { cn } from '@/lib/utils'

interface SimSubject {
  id: string
  code: string
  name: string
  held: number
  attended: number
}

export function RecoverySimulator({ subjects, initialSubjectId }: { subjects: SimSubject[]; initialSubjectId: string }) {
  const [subjectId, setSubjectId] = useState(initialSubjectId)
  const sub = subjects.find((s) => s.id === subjectId) ?? subjects[0]
  const needed = classesNeeded(sub.held, sub.attended)
  const [upcoming, setUpcoming] = useState(Math.max(needed, 10))
  const [attend, setAttend] = useState(Math.max(needed, 10))

  const total = sub.held + upcoming
  const att = sub.attended + Math.min(attend, upcoming)
  const pct = percentage(total, att)
  const tier = tierFor(pct)
  const minToAttend = Math.max(0, Math.ceil(0.75 * total - sub.attended))
  const feasible = minToAttend <= upcoming

  function changeSubject(id: string) {
    setSubjectId(id)
    const s = subjects.find((x) => x.id === id)!
    const n = Math.max(classesNeeded(s.held, s.attended), 10)
    setUpcoming(n)
    setAttend(n)
  }

  return (
    <Card className="gap-4 p-5">
      <div className="flex items-center gap-2">
        <Calculator className="size-5 text-primary" aria-hidden="true" />
        <h2 className="font-semibold">What-if recovery simulator</h2>
      </div>

      <div className="flex flex-col gap-1.5">
        <Label htmlFor="sim-subject">Subject</Label>
        <select
          id="sim-subject"
          value={subjectId}
          onChange={(e) => changeSubject(e.target.value)}
          className="h-9 rounded-lg border border-input bg-card px-2.5 text-sm"
        >
          {subjects.map((s) => (
            <option key={s.id} value={s.id}>
              {s.code} {s.name} ({formatPct(percentage(s.held, s.attended))})
            </option>
          ))}
        </select>
      </div>

      <div className="flex flex-col gap-1.5">
        <div className="flex items-baseline justify-between">
          <Label htmlFor="sim-upcoming">Upcoming classes this term</Label>
          <span className="font-mono text-sm font-semibold tabular-nums">{upcoming}</span>
        </div>
        <input
          id="sim-upcoming"
          type="range"
          min={1}
          max={40}
          value={upcoming}
          onChange={(e) => {
            const v = Number(e.target.value)
            setUpcoming(v)
            setAttend((a) => Math.min(a, v))
          }}
          className="accent-primary"
        />
      </div>

      <div className="flex flex-col gap-1.5">
        <div className="flex items-baseline justify-between">
          <Label htmlFor="sim-attend">Classes the student attends</Label>
          <span className="font-mono text-sm font-semibold tabular-nums">{Math.min(attend, upcoming)}</span>
        </div>
        <input
          id="sim-attend"
          type="range"
          min={0}
          max={upcoming}
          value={Math.min(attend, upcoming)}
          onChange={(e) => setAttend(Number(e.target.value))}
          className="accent-primary"
        />
      </div>

      <div className="rounded-lg bg-muted/60 p-4">
        <div className="flex items-center justify-between">
          <span className="text-sm text-muted-foreground">Projected attendance</span>
          <RiskBadge tier={tier} />
        </div>
        <p className={cn('mt-1 font-mono text-3xl font-semibold tabular-nums', tierTextClass(tier))}>{formatPct(pct)}</p>
        <AttendanceBar pct={pct} tier={tier} className="mt-2" />
        <p className="mt-3 text-pretty text-sm">
          {feasible ? (
            <>
              Of the next <strong>{upcoming}</strong> classes, the student must attend at least{' '}
              <strong className="tabular-nums">{minToAttend}</strong> to finish at 75% or above ({att}/{total}).
            </>
          ) : (
            <span className="text-critical">
              Even attending all {upcoming} upcoming classes leaves the student short. Recovery needs at least {needed}{' '}
              consecutive classes, or a condonation / medical exemption.
            </span>
          )}
        </p>
      </div>
    </Card>
  )
}
