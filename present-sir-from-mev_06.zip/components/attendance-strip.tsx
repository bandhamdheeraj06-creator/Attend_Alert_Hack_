import type { Status } from '@/lib/types'
import { cn } from '@/lib/utils'

const COLOR: Record<Status, string> = { P: 'bg-safe', L: 'bg-warning', A: 'bg-critical' }
const LABEL: Record<Status, string> = { P: 'Present', L: 'Late', A: 'Absent' }

export function AttendanceStrip({ items }: { items: { date: string; status: Status }[] }) {
  if (items.length === 0) return null
  return (
    <div className="flex flex-wrap gap-1" aria-label="Class-by-class history">
      {items.map((it) => (
        <span
          key={it.date}
          title={`${it.date}: ${LABEL[it.status]}`}
          className={cn('h-4 w-2.5 rounded-sm', COLOR[it.status])}
        >
          <span className="sr-only">{`${it.date}: ${LABEL[it.status]}`}</span>
        </span>
      ))}
    </div>
  )
}
