'use client'

import { useTransition } from 'react'
import { RotateCcw } from 'lucide-react'
import { resetDemoData } from '@/app/actions'
import { Button } from '@/components/ui/button'

export function ResetDemoButton() {
  const [pending, startTransition] = useTransition()
  return (
    <Button
      variant="outline"
      size="lg"
      disabled={pending}
      onClick={() => {
        if (confirm('Reset all attendance, alerts and interventions to the original demo dataset?')) {
          startTransition(async () => {
            await resetDemoData()
          })
        }
      }}
    >
      <RotateCcw className={pending ? 'size-4 animate-spin' : 'size-4'} aria-hidden="true" />
      Reset demo data
    </Button>
  )
}
