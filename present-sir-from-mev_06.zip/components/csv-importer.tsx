'use client'

import { useState, useTransition } from 'react'
import { Download, FileSpreadsheet, Loader2, Upload } from 'lucide-react'
import { importAttendance, importRoster, type ImportResult } from '@/app/actions'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { cn } from '@/lib/utils'

function parseCsv(text: string): Record<string, string>[] {
  const rows: string[][] = []
  let field = ''
  let row: string[] = []
  let quoted = false
  for (let i = 0; i < text.length; i++) {
    const c = text[i]
    if (quoted) {
      if (c === '"' && text[i + 1] === '"') {
        field += '"'
        i++
      } else if (c === '"') quoted = false
      else field += c
    } else if (c === '"') quoted = true
    else if (c === ',') {
      row.push(field)
      field = ''
    } else if (c === '\n' || c === '\r') {
      if (c === '\r' && text[i + 1] === '\n') i++
      row.push(field)
      if (row.some((v) => v.trim())) rows.push(row)
      row = []
      field = ''
    } else field += c
  }
  row.push(field)
  if (row.some((v) => v.trim())) rows.push(row)
  const [header, ...body] = rows
  if (!header) return []
  const keys = header.map((h) => h.trim().toLowerCase().replace(/[^a-z]/g, ''))
  return body.map((r) => Object.fromEntries(keys.map((k, i) => [k, (r[i] ?? '').trim()])))
}

const KINDS = {
  roster: {
    title: 'Class roster',
    description: 'Adds new students or updates existing ones by roll number.',
    columns: 'roll, name, email, parent_email, section',
    sample: 'roll,name,email,parent_email,section\n22CSE031,Sanya Kapoor,sanya.kapoor@student.attendalert.edu,parent.sanya@mail.com,CSE-A\n22CSE032,Rajat Sen,,parent.rajat@mail.com,CSE-A\n',
  },
  attendance: {
    title: 'Biometric / attendance log',
    description: 'Creates sessions as needed and upserts each student record. Status accepts P/A/L, present/absent/late or 1/0.',
    columns: 'date, subject_code, roll, status',
    sample: 'date,subject_code,roll,status\n2026-11-17,CS301,22CSE001,A\n2026-11-17,CS301,22CSE002,P\n2026-11-17,CS301,22CSE003,L\n',
  },
} as const

type Kind = keyof typeof KINDS

function ImportCard({ kind }: { kind: Kind }) {
  const cfg = KINDS[kind]
  const [rows, setRows] = useState<Record<string, string>[]>([])
  const [fileName, setFileName] = useState('')
  const [result, setResult] = useState<ImportResult | null>(null)
  const [pending, startTransition] = useTransition()

  async function onFile(file: File | undefined) {
    setResult(null)
    if (!file) return
    setFileName(file.name)
    setRows(parseCsv(await file.text()))
  }

  function onImport() {
    startTransition(async () => {
      const res =
        kind === 'roster'
          ? await importRoster(rows.map((r) => ({ roll: r.roll, name: r.name, email: r.email, parentEmail: r.parentemail, section: r.section })))
          : await importAttendance(rows.map((r) => ({ date: r.date, subjectCode: r.subjectcode, roll: r.roll, status: r.status })))
      setResult(res)
      if (res.ok) setRows([])
    })
  }

  const sampleHref = `data:text/csv;charset=utf-8,${encodeURIComponent(cfg.sample)}`
  const preview = rows.slice(0, 5)
  const headers = preview[0] ? Object.keys(preview[0]) : []

  return (
    <Card className="gap-4 p-5">
      <div className="flex items-start gap-3">
        <span className="flex size-10 shrink-0 items-center justify-center rounded-lg bg-accent text-accent-foreground">
          <FileSpreadsheet className="size-5" aria-hidden="true" />
        </span>
        <div className="flex-1">
          <h2 className="font-semibold">{cfg.title}</h2>
          <p className="text-pretty text-sm text-muted-foreground">{cfg.description}</p>
          <p className="mt-1 font-mono text-xs text-muted-foreground">Columns: {cfg.columns}</p>
        </div>
      </div>

      <label
        className={cn(
          'flex cursor-pointer flex-col items-center gap-2 rounded-xl border-2 border-dashed p-6 text-center transition-colors hover:border-primary hover:bg-accent/40',
          fileName && 'border-primary/50',
        )}
      >
        <Upload className="size-6 text-muted-foreground" aria-hidden="true" />
        <span className="text-sm font-medium">{fileName || 'Choose a CSV file'}</span>
        <span className="text-xs text-muted-foreground">{rows.length ? `${rows.length} rows parsed` : '.csv up to a few MB'}</span>
        <input type="file" accept=".csv,text/csv" className="sr-only" onChange={(e) => onFile(e.target.files?.[0])} />
      </label>

      {preview.length > 0 && (
        <div className="overflow-x-auto rounded-lg border">
          <table className="w-full text-xs">
            <thead className="bg-muted/60">
              <tr>{headers.map((h) => <th key={h} scope="col" className="px-2 py-1.5 text-left font-medium">{h}</th>)}</tr>
            </thead>
            <tbody>
              {preview.map((r, i) => (
                <tr key={i} className="border-t">
                  {headers.map((h) => <td key={h} className="px-2 py-1.5 font-mono">{r[h]}</td>)}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {result && (
        <p role="status" className={cn('rounded-lg px-3 py-2 text-sm', result.ok ? 'bg-safe-soft text-safe' : 'bg-critical-soft text-critical')}>
          {result.ok
            ? `Imported: ${result.created} created, ${result.updated} updated, ${result.skipped} skipped${result.sessionsCreated ? `, ${result.sessionsCreated} new sessions` : ''}.`
            : result.error}
        </p>
      )}

      <div className="flex flex-wrap gap-2">
        <Button onClick={onImport} disabled={!rows.length || pending}>
          {pending && <Loader2 className="size-4 animate-spin" aria-hidden="true" />}
          Import {rows.length || ''} rows
        </Button>
        <a href={sampleHref} download={`sample-${kind}.csv`} className="inline-flex h-8 items-center gap-1.5 rounded-lg px-2.5 text-sm font-medium text-primary hover:bg-accent">
          <Download className="size-4" aria-hidden="true" />
          Sample CSV
        </a>
      </div>
    </Card>
  )
}

export function CsvImporter() {
  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <ImportCard kind="roster" />
      <ImportCard kind="attendance" />
    </div>
  )
}
