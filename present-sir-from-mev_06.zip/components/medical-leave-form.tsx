'use client'

import { useActionState, useEffect, useRef } from 'react'
import { CheckCircle2, FileUp, Loader2 } from 'lucide-react'
import { submitMedicalLeave, type LeaveState } from '@/app/actions'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'

export function MedicalLeaveForm() {
  const [state, formAction, pending] = useActionState<LeaveState, FormData>(submitMedicalLeave, {})
  const ref = useRef<HTMLFormElement>(null)
  useEffect(() => {
    if (state.ok) ref.current?.reset()
  }, [state])

  return (
    <form ref={ref} action={formAction} className="flex flex-col gap-3">
      <div className="grid grid-cols-2 gap-3">
        <div className="flex flex-col gap-1.5">
          <Label htmlFor="leave-from">From</Label>
          <Input id="leave-from" name="from" type="date" required className="h-9" />
        </div>
        <div className="flex flex-col gap-1.5">
          <Label htmlFor="leave-to">To</Label>
          <Input id="leave-to" name="to" type="date" required className="h-9" />
        </div>
      </div>
      <div className="flex flex-col gap-1.5">
        <Label htmlFor="leave-reason">Medical reason</Label>
        <Textarea id="leave-reason" name="reason" required rows={2} placeholder="e.g. Viral fever, advised bed rest" />
      </div>
      <div className="flex flex-col gap-1.5">
        <Label htmlFor="leave-cert">Medical certificate (PDF / image, max 1 MB)</Label>
        <Input id="leave-cert" name="certificate" type="file" accept="application/pdf,image/png,image/jpeg,image/webp" required className="h-9 py-1.5" />
      </div>
      {state.error && <p role="alert" className="text-sm text-critical">{state.error}</p>}
      {state.ok && (
        <p role="status" className="flex items-center gap-1.5 text-sm text-safe">
          <CheckCircle2 className="size-4" aria-hidden="true" /> Submitted. Your mentor will review it.
        </p>
      )}
      <Button type="submit" disabled={pending} className="self-start">
        {pending ? <Loader2 className="size-4 animate-spin" aria-hidden="true" /> : <FileUp className="size-4" aria-hidden="true" />}
        Submit for exemption
      </Button>
    </form>
  )
}
