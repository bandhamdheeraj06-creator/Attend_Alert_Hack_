'use client'

import Link from 'next/link'
import { useMemo, useState } from 'react'
import { ArrowUpDown, ChevronRight, Search } from 'lucide-react'
import { Input } from '@/components/ui/input'
import { Card } from '@/components/ui/card'
import { AttendanceBar, RiskBadge, tierTextClass } from '@/components/risk-badge'
import { formatPct, TIER_RANK, type Tier } from '@/lib/attendance'
import { cn } from '@/lib/utils'

export interface RiskRow {
  id: string
  roll: string
  name: string
  overallPct: number
  subjects: { subjectId: string; pct: number; tier: Tier; needed: number; attended: number; held: number }[]
}

type TierFilter = 'all' | 'at-risk' | Tier

const TIER_FILTERS: { key: TierFilter; label: string }[] = [
  { key: 'at-risk', label: 'At risk' },
  { key: 'critical', label: 'Critical' },
  { key: 'warning', label: 'Warning' },
  { key: 'safe', label: 'Safe' },
  { key: 'all', label: 'All' },
]

export function AtRiskTable({
  rows,
  subjects,
}: {
  rows: RiskRow[]
  subjects: { id: string; code: string; name: string }[]
}) {
  const [query, setQuery] = useState('')
  const [tier, setTier] = useState<TierFilter>('at-risk')
  const [subjectId, setSubjectId] = useState<string>('worst')
  const [sortAsc, setSortAsc] = useState(true)

  const view = useMemo(() => {
    const q = query.trim().toLowerCase()
    return rows
      .map((row) => {
        const focus =
          subjectId === 'worst'
            ? [...row.subjects].sort((a, b) => a.pct - b.pct)[0]
            : row.subjects.find((s) => s.subjectId === subjectId)!
        const atRiskCount = row.subjects.filter((s) => s.tier !== 'safe').length
        return { ...row, focus, atRiskCount }
      })
      .filter((row) => {
        if (q && !row.name.toLowerCase().includes(q) && !row.roll.toLowerCase().includes(q)) return false
        if (tier === 'all') return true
        if (tier === 'at-risk') return row.focus.tier !== 'safe'
        return row.focus.tier === tier
      })
      .sort((a, b) =>
        sortAsc
          ? TIER_RANK[a.focus.tier] - TIER_RANK[b.focus.tier] || a.focus.pct - b.focus.pct
          : b.focus.pct - a.focus.pct,
      )
  }, [rows, query, tier, subjectId, sortAsc])

  const subjectLabel = (id: string) => subjects.find((s) => s.id === id)

  return (
    <Card className="gap-0 p-0">
      <div className="flex flex-col gap-3 border-b p-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h2 className="font-semibold">Early-warning roster</h2>
          <p className="text-xs text-muted-foreground">Click a student to open recovery plan and log interventions.</p>
        </div>
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
          <div className="relative">
            <Search className="pointer-events-none absolute left-2.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search name or roll no."
              aria-label="Search students"
              className="h-9 pl-8 sm:w-56"
            />
          </div>
          <label className="sr-only" htmlFor="subject-filter">
            Subject
          </label>
          <select
            id="subject-filter"
            value={subjectId}
            onChange={(e) => setSubjectId(e.target.value)}
            className="h-9 rounded-lg border border-input bg-card px-2.5 text-sm"
          >
            <option value="worst">All subjects (lowest)</option>
            {subjects.map((s) => (
              <option key={s.id} value={s.id}>
                {s.code} {s.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div role="tablist" aria-label="Risk tier filter" className="flex gap-1 overflow-x-auto border-b px-4 py-2">
        {TIER_FILTERS.map((f) => (
          <button
            key={f.key}
            role="tab"
            aria-selected={tier === f.key}
            onClick={() => setTier(f.key)}
            className={cn(
              'shrink-0 rounded-md px-3 py-1.5 text-xs font-medium transition-colors',
              tier === f.key ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:bg-muted',
            )}
          >
            {f.label}
          </button>
        ))}
        <span className="ml-auto self-center text-xs text-muted-foreground">{view.length} students</span>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-left text-xs text-muted-foreground">
            <tr>
              <th scope="col" className="px-4 py-2.5 font-medium">Student</th>
              <th scope="col" className="px-4 py-2.5 font-medium">{subjectId === 'worst' ? 'Lowest subject' : 'Subject'}</th>
              <th scope="col" className="px-4 py-2.5 font-medium">
                <button onClick={() => setSortAsc((v) => !v)} className="inline-flex items-center gap-1 hover:text-foreground">
                  Attendance <ArrowUpDown className="size-3" aria-hidden="true" />
                </button>
              </th>
              <th scope="col" className="px-4 py-2.5 font-medium">Tier</th>
              <th scope="col" className="px-4 py-2.5 font-medium">Recovery</th>
              <th scope="col" className="px-4 py-2.5 font-medium">Overall</th>
              <th scope="col" className="w-8 px-4 py-2.5"><span className="sr-only">Open</span></th>
            </tr>
          </thead>
          <tbody>
            {view.map((row) => {
              const sub = subjectLabel(row.focus.subjectId)
              return (
                <tr key={row.id} className="group border-t hover:bg-muted/40">
                  <td className="px-4 py-3">
                    <Link href={`/mentor/students/${row.id}`} className="flex flex-col after:absolute">
                      <span className="font-medium group-hover:text-primary">{row.name}</span>
                      <span className="font-mono text-xs text-muted-foreground">{row.roll}</span>
                    </Link>
                  </td>
                  <td className="px-4 py-3">
                    <span className="font-medium">{sub?.name}</span>
                    {row.atRiskCount > 1 && subjectId === 'worst' && (
                      <span className="ml-1.5 text-xs text-muted-foreground">+{row.atRiskCount - 1} more</span>
                    )}
                  </td>
                  <td className="min-w-40 px-4 py-3">
                    <div className="flex items-center gap-3">
                      <span className={cn('w-14 font-mono text-sm font-semibold tabular-nums', tierTextClass(row.focus.tier))}>
                        {formatPct(row.focus.pct)}
                      </span>
                      <AttendanceBar pct={row.focus.pct} tier={row.focus.tier} className="w-20" />
                    </div>
                    <span className="text-xs text-muted-foreground tabular-nums">
                      {row.focus.attended}/{row.focus.held} classes
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <RiskBadge tier={row.focus.tier} />
                  </td>
                  <td className="px-4 py-3">
                    {row.focus.needed > 0 ? (
                      <span className="text-sm">
                        Attend next <span className="font-semibold tabular-nums">{row.focus.needed}</span>
                      </span>
                    ) : (
                      <span className="text-xs text-muted-foreground">Eligible</span>
                    )}
                  </td>
                  <td className="px-4 py-3 font-mono text-xs tabular-nums text-muted-foreground">{formatPct(row.overallPct)}</td>
                  <td className="px-4 py-3">
                    <Link href={`/mentor/students/${row.id}`} aria-label={`Open ${row.name}`}>
                      <ChevronRight className="size-4 text-muted-foreground group-hover:text-primary" aria-hidden="true" />
                    </Link>
                  </td>
                </tr>
              )
            })}
            {view.length === 0 && (
              <tr>
                <td colSpan={7} className="px-4 py-10 text-center text-sm text-muted-foreground">
                  No students match these filters.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </Card>
  )
}
