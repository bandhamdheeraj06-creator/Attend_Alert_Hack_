'use client'

import { useActionState, useEffect, useRef } from 'react'
import { CheckCircle2, Loader2, NotebookPen } from 'lucide-react'
import { logIntervention, type InterventionState } from '@/app/actions'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'

export function InterventionForm({
  studentId,
  subjects,
  defaultSubjectId,
}: {
  studentId: string
  subjects: { id: string; code: string; name: string }[]
  defaultSubjectId: string
}) {
  const [state, formAction, pending] = useActionState<InterventionState, FormData>(logIntervention, {})
  const formRef = useRef<HTMLFormElement>(null)

  useEffect(() => {
    if (state.ok) formRef.current?.reset()
  }, [state])

  return (
    <form ref={formRef} action={formAction} id="log-intervention" className="flex flex-col gap-4 scroll-mt-24">
      <input type="hidden" name="studentId" value={studentId} />
      <div className="flex items-center gap-2">
        <NotebookPen className="size-5 text-primary" aria-hidden="true" />
        <h2 className="font-semibold">Log Mentoring Intervention</h2>
      </div>
      <div className="grid gap-3 sm:grid-cols-2">
        <div className="flex flex-col gap-1.5">
          <Label htmlFor="int-subject">Regarding subject</Label>
          <select
            id="int-subject"
            name="subjectId"
            defaultValue={defaultSubjectId}
            className="h-9 rounded-lg border border-input bg-card px-2.5 text-sm"
          >
            <option value="">General / all subjects</option>
            {subjects.map((s) => (
              <option key={s.id} value={s.id}>
                {s.code} {s.name}
              </option>
            ))}
          </select>
        </div>
        <div className="flex flex-col gap-1.5">
          <Label htmlFor="int-followup">Follow-up date</Label>
          <Input id="int-followup" name="followUp" type="date" className="h-9" />
        </div>
      </div>
      <div className="flex flex-col gap-1.5">
        <Label htmlFor="int-note">Counselling notes</Label>
        <Textarea
          id="int-note"
          name="note"
          required
          rows={3}
          placeholder="Reason for absences discussed, student's circumstances..."
        />
      </div>
      <div className="flex flex-col gap-1.5">
        <Label htmlFor="int-plan">Agreed action plan</Label>
        <Textarea id="int-plan" name="actionPlan" rows={2} placeholder="e.g. Attend all 8 upcoming DS lectures; weekly check-in" />
      </div>
      {state.error && <p role="alert" className="text-sm text-critical">{state.error}</p>}
      {state.ok && (
        <p role="status" className="flex items-center gap-1.5 text-sm text-safe">
          <CheckCircle2 className="size-4" aria-hidden="true" /> Intervention recorded.
        </p>
      )}
      <Button type="submit" disabled={pending} className="self-start">
        {pending && <Loader2 className="size-4 animate-spin" aria-hidden="true" />}
        Save intervention
      </Button>
    </form>
  )
}
