'use client'

import { useActionState, useState } from 'react'
import { GraduationCap, Loader2, ShieldCheck } from 'lucide-react'
import { login, type LoginState } from '@/app/actions'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { cn } from '@/lib/utils'

const DEMO = {
  mentor: { identifier: 'mentor@attendalert.edu', password: 'mentor123' },
  student: { identifier: '22CSE001', password: 'student123' },
}

export function LoginForm() {
  const [role, setRole] = useState<'mentor' | 'student'>('mentor')
  const [identifier, setIdentifier] = useState(DEMO.mentor.identifier)
  const [password, setPassword] = useState(DEMO.mentor.password)
  const [state, formAction, pending] = useActionState<LoginState, FormData>(login, {})

  function switchRole(next: 'mentor' | 'student') {
    setRole(next)
    setIdentifier(DEMO[next].identifier)
    setPassword(DEMO[next].password)
  }

  return (
    <form action={formAction} className="flex flex-col gap-5">
      <input type="hidden" name="role" value={role} />
      <div role="radiogroup" aria-label="Sign in as" className="grid grid-cols-2 gap-2 rounded-xl bg-muted p-1">
        {(
          [
            { key: 'mentor', label: 'Faculty / Mentor', icon: ShieldCheck },
            { key: 'student', label: 'Student', icon: GraduationCap },
          ] as const
        ).map(({ key, label, icon: Icon }) => (
          <button
            key={key}
            type="button"
            role="radio"
            aria-checked={role === key}
            onClick={() => switchRole(key)}
            className={cn(
              'flex items-center justify-center gap-2 rounded-lg px-3 py-2 text-sm font-medium transition-colors',
              role === key ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground',
            )}
          >
            <Icon className="size-4" aria-hidden="true" />
            {label}
          </button>
        ))}
      </div>

      <div className="flex flex-col gap-2">
        <Label htmlFor="identifier">{role === 'mentor' ? 'Faculty email' : 'Roll number'}</Label>
        <Input
          id="identifier"
          name="identifier"
          value={identifier}
          onChange={(e) => setIdentifier(e.target.value)}
          autoComplete="username"
          className="h-10"
          required
        />
      </div>
      <div className="flex flex-col gap-2">
        <Label htmlFor="password">Password</Label>
        <Input
          id="password"
          name="password"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          autoComplete="current-password"
          className="h-10"
          required
        />
      </div>

      {state.error && (
        <p role="alert" className="rounded-lg bg-critical-soft px-3 py-2 text-sm text-critical">
          {state.error}
        </p>
      )}

      <Button type="submit" size="lg" className="h-10" disabled={pending}>
        {pending && <Loader2 className="size-4 animate-spin" aria-hidden="true" />}
        {role === 'mentor' ? 'Sign in to Mentor Console' : 'Open my Attendance Portal'}
      </Button>

      <div className="rounded-lg border border-dashed p-3 text-xs leading-relaxed text-muted-foreground">
        <p className="font-medium text-foreground">Demo accounts (pre-filled)</p>
        <p>
          Mentor: <span className="font-mono">mentor@attendalert.edu</span> / <span className="font-mono">mentor123</span>
        </p>
        <p>
          Student: <span className="font-mono">22CSE001</span> {'-'} <span className="font-mono">22CSE030</span> /{' '}
          <span className="font-mono">student123</span>
        </p>
      </div>
    </form>
  )
}
