'use client'

import { useState, useTransition } from 'react'
import { Check, Loader2, X } from 'lucide-react'
import { reviewMedicalLeave } from '@/app/actions'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'

export function LeaveReview({ leaveId, impact }: { leaveId: string; impact: string }) {
  const [note, setNote] = useState('')
  const [pending, startTransition] = useTransition()

  const decide = (decision: 'approved' | 'rejected') =>
    startTransition(async () => {
      await reviewMedicalLeave(leaveId, decision, note)
    })

  return (
    <div className="flex flex-col gap-2">
      <p className="text-xs text-muted-foreground">{impact}</p>
      <div className="flex flex-col gap-2 sm:flex-row">
        <Input
          value={note}
          onChange={(e) => setNote(e.target.value)}
          placeholder="Review note (optional)"
          aria-label="Review note"
          className="h-9"
        />
        <div className="flex gap-2">
          <Button onClick={() => decide('approved')} disabled={pending} className="bg-safe text-white hover:bg-safe/90">
            {pending ? <Loader2 className="size-4 animate-spin" aria-hidden="true" /> : <Check className="size-4" aria-hidden="true" />}
            Approve
          </Button>
          <Button variant="outline" onClick={() => decide('rejected')} disabled={pending}>
            <X className="size-4" aria-hidden="true" />
            Reject
          </Button>
        </div>
      </div>
    </div>
  )
}
